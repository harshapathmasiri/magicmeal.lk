<?php session_start() ?>

<?php
$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/style_index.css" />
        <link rel="stylesheet" type="text/css" href="css/" />

        <script src="js/script.js"></script>

        <title>About Us | Magic Meal Food Ordering System</title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body>
        <?php
        include_once("includes/navbar.php");
        ?>


        <div class="cover" id="coverImg">
            <div class="coverOverlay">
                <h1>About Us</h1>
                <div class="downArrow" id="idDownArrow">
                    <img id="idImgDownArrow" name="imgDownArrow" src="images/icons/downarrow2.png" width="100" onclick="scrollToAbout()" onmouseover="downArrowMouseOver()" onmouseout="downArrowMouseOut()"/>
                </div>
            </div>
        </div>

        <div class="content" id="idContent">
            <div class="aboutContainer">
                <h1 class="aboutTitle">WHY MAGIC MEAL?</h1>

                <table align="center" border="0" class="tblAbout">
                    <tr>
                        <td>
                            <div class="aboutDescription aboutContentCommon">
                                <p>
                                
                                    “Join us in our journey to make every meal a magical experience, one plate at a time.” 
                                </p>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="content" id="idContent">
            <div class="aboutContainer">


                <table align="center" border="0" class="tblAbout">
                    <tr>
                        <td>
                            <h1 class="aboutTitle">About Magic Meal Food</h1>
                            <div class="aboutDescription aboutContentCommon">
                                <p> Welcome to Magic Meal Food Catering Service, where culinary expertise meets your every craving.

At Magic Meal, we're not just about food; we're about crafting memorable experiences, one dish at a time. Our journey began with a passion for exceptional cuisine and a commitment to making every event extraordinary.

Our Story

Magic Meal Food Catering Service was founded by a group of food enthusiasts who wanted to redefine catering. We saw a gap in the market for catering services that combined gourmet flavors with the convenience of full-service event planning. So, in [Year of Establishment], we embarked on a mission to create unforgettable dining experiences that tantalize taste buds and leave a lasting impression.
                                    
                                </p>
                            </div>
                        </td>
                        
                        <td style="padding-left: 80px"></td>
                        
                        <td>
                            <h1 class="aboutTitle">MISSION</h1>
                            <div class="aboutDescription aboutContentCommon">
                                <p>
                                    At Magic Meal Food Catering Service, our mission is simple yet profound: to transform ordinary moments into extraordinary memories through the art of culinary excellence. We aspire to:
                                </p>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="content1">
            <h1 class="servTitle">SERVICES WE PROVIDE</h1>
            <table align="center" border="0" class="tblServCards">
                <tr>

                    <td>
                        <div class="weddings sCard">
                            <div class="servCardOverlay">
                               class="servCardOverlayBtnView">View More</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/service_cards/camera.jpg" />
                                <p class="servCardTitle">Live Cooking View</p>
                            </div>



                            <div class="servCardDesc">
                                <p>Let's See How To Cook Our Chef in Kitchen.</p>
                            </div>
                        </div>
                    </td>	

                     <td>
                        <div class="music sCard">
                            <div class="servCardOverlay">
                                a href="servMusicIB.php" class="servCardOverlayBtnView">View More</a>
                            </div>
                            <div class="musicImg img">
                                <img src="images/service_cards/chairs.jpg" />
                                <p class="servCardTitle">Talk with Chef</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Let's Talk with Chef While Preaparing Your Delicious Food.</p>
                            </div>
                        </div>
                    </td>


                    <td>
                        <div class="catering sCard">
                            <div class="servCardOverlay">
                                class="servCardOverlayBtnView">View More</a>
                            </div>
                            <div class="caterImg img">
                                <img src="images/service_cards/catering.jpg" />
                                <p class="servCardTitle">Online Order & Delivery</p>
                            </div>



                            <div class="servCardDesc">
                                <p>Choose between different types of set menu food items. All the food items can prepare while you watching.</p>
                            </div>
                        </div>

                </tr>

                <tr>

                    <td>
                        <div class="lights sCard">
                            <div class="servCardOverlay">
                                class="servCardOverlayBtnView">View More</a>
                            </div>
                            <div class="lightsImg img">
                                <img src="images/service_cards/food-delivery-industry.jpg" />
                                <p class="servCardTitle">Quick Food Delievery</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Quick Delivery for Your Special Occasion.</p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="stages sCard">
                            <div class="servCardOverlay">
                                class="servCardOverlayBtnView">View More</a>
                            </div>
                            <div class="stagesImg img">
                                <img src="images/service_cards/cooking.jpg" />
                                <p class="servCardTitle">Kitchen Camera</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Live Camera View will Help You To See The Recipe</p>
                            </div>
                    </td>

                    <td>
                        <div class="Functions sCard">
                            <div class="servCardOverlay">
                                class="servCardOverlayBtnView">View More</a>
                            </div>
                            <div class="functionsImg img">
                                <img src="images/service_cards/buffet.jpg" />
                                <p class="servCardTitle">Buffet Catering</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Customize Your Buffet Dishes with Us.</p>
                            </div>
                        </div>
                    </td>


                        </div>
                    </td>
                </tr>

            </table>
        </div>

        <?php
        include_once("includes/footer.php");
        ?>
        <script type="text/javascript">

        </script>

        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDz_qDNvKnEONeyMDwl0jRB8R39YkYDyiQ &callback=initMap" type="text/javascript"></script>


    </body>

</html>
