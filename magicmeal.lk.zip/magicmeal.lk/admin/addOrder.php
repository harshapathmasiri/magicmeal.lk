<?php
session_start();

include '../includes/db.php';
include '../includes/Upload.php';
include '../functions.php';


if (!isset($_SESSION['user'])) {
    echo '<script>window.location = "login.php";</script>';
}
if ($_SESSION['user']) {

    $username = $_SESSION['user'];

    $sql = "SELECT * FROM admin WHERE username='$username'";

    $db = new DB();

    $result = $db->readQuery($sql);
    $row = mysqli_fetch_assoc($result);
}

if (isset($_POST['submit'])) {
    $addDoc = addAppointment($_POST);
    if ($addDoc) {
        $success = "Successfully Done!";
    } else {
        $error = "Error";
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Add Order | Sandy's Catering Admin</title>
        <!-- Fav  Icon Link -->
        <link rel="shortcut icon" type="image/png" href="images/fav.png">
        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- themify icons CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- Animations CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- Main CSS -->
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/red.css" id="style_theme">
        <link rel="stylesheet" href="css/responsive.css">
        <!-- morris charts -->
        <link rel="stylesheet" href="charts/css/morris.css">
        <!-- jvectormap -->
        <link rel="stylesheet" href="css/jquery-jvectormap.css">

        <script src="js/modernizr.min.js"></script>
    </head>

    <body>

        <div class="wrapper">

            <?php include './left-bar.php'; ?>
            <!-- Page Content -->

            <div id="content">
                <?php include './header.php'; ?>
                <!-- Breadcrumb -->
                <!-- Page Title -->
                <div class="row no-margin-padding">
                    <div class="col-md-6">
                        <h3 class="block-title">Quick Statistics</h3>
                    </div>
                    <div class="col-md-6">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="index.html">
                                    <span class="ti-home"></span>
                                </a>
                            </li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                <!-- /Page Title -->

                <!-- /Breadcrumb -->

                <!-- Main Content -->
                <div class="container-fluid">

                    <div class="row">
                        <!-- Widget Item -->
                        <div class="col-md-12">
                            <div class="widget-area-2 proclinic-box-shadow">
                                <?php
                                if ($success) {
                                    ?>
                                    <!-- Alerts-->
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Successfully Done!</strong> Please Check in orders list
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <?php
                                }
                                if ($error) {
                                    ?>

                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Oops !</strong> You should check in on some of those fields below.
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <!-- /Alerts--> 
                                    <?php
                                }
                                ?>

                                <h3 class="widget-title">Add Order</h3>
                                <form action="" method="post" enctype="multipart/form-data">
                                    <div class="form-row">

                                        <input type="hidden" class="form-control" name="patient" value="<?php echo $row['admin_id']; ?>"> 

                                        <div class="form-group col-md-6">
                                            <label for="firstName">First Name</label>
                                            <input type="text" class="form-control" name="firstName" placeholder="First Name" id="firstName">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="lastName">Last Name</label>
                                            <input type="text" class="form-control" name="lastName" placeholder="Last Name" id="lastName">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="doctor">Doctor</label>

                                            <select class="form-control" name="doctor" id="doctor">
                                                <option hidden>Select Doctor</option>
                                                <?php
                                                $allDoc = getAll("doctor", "first_name ASC");
                                                if (count($allDoc) > 0) {
                                                    foreach ($allDoc as $key => $doctor) {
                                                        ?>
                                                        <option value="<?php echo $doctor['id']; ?>"><?php echo $doctor['first_name'] . " " . $doctor['last_name']; ?></option>  
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="age">Age</label>
                                            <input type="text" placeholder="Age" name="age" class="form-control" id="age">
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="gender">Gender</label>
                                            <select class="form-control" name="gender" id="gender">
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option> 
                                            </select>
                                        </div> 
                                        <div class="form-group col-md-6">
                                            <label for="phone">Phone</label>
                                            <input type="text" placeholder="Phone" name="phone" class="form-control" id="phone">
                                        </div> 
                                        <div class="form-group col-md-6">
                                            <label for="date">Date</label>
                                            <input type="date" placeholder="date" name="date" class="form-control" id="date">
                                        </div> 
                                        <div class="form-group col-md-6">
                                            <label for="time">Time</label>
                                            <select class="form-control" name="time" id="time">
                                                <option value="6AM">6.00 AM</option>
                                                <option value="4PM">4.00 PM</option> 
                                            </select>
                                        </div>  
                                        <div class="form-group col-md-12">
                                            <label for="message">Message</label>
                                            <textarea class="form-control" name="message" id="message"></textarea>
                                        </div>  

                                        <div class="form-group col-md-6 mb-3">
                                            <button type="submit" name="submit" class="btn btn-primary btn-lg">Submit</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                        <!-- /Widget Item -->
                    </div>
                </div>
                <!-- /Main Content -->
            </div>
            <!-- /Page Content -->
        </div>
        <!-- Back to Top -->
        <a id="back-to-top" href="#" class="back-to-top">
            <span class="ti-angle-up"></span>
        </a>
        <!-- /Back to Top -->

        <!-- Jquery Library-->
        <script src="js/jquery-3.2.1.min.js"></script>
        <!-- Popper Library-->
        <script src="js/popper.min.js"></script>
        <!-- Bootstrap Library-->
        <script src="js/bootstrap.min.js"></script>
        <!-- morris charts -->
        <script src="charts/js/raphael-min.js"></script>
        <script src="charts/js/morris.min.js"></script>
        <script src="js/custom-morris.js"></script>

        <!-- Custom Script-->
        <script src="js/custom.js"></script>
    </body>

</html>