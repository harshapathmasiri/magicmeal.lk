<?php
session_start();

include '../includes/db.php';
include '../includes/Upload.php';
include '../functions.php';

if (!isset($_SESSION['user'])) {
    echo '<script>window.location = "login.php";</script>';
}
if ($_SESSION['user']) {

    $username = $_SESSION['user'];

    $sql = "SELECT * FROM admin WHERE username='$username'";

    $db = new DB();

    $result = $db->readQuery($sql);
    $row = mysqli_fetch_assoc($result);
}

if (isset($_POST['submit'])) {
    $addPatient = addPatient($_POST);
    if ($addPatient) {
        $success = "Successfully Done!";
    } else {
        $error = "Error";
    }
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Add User | Sandy's Catering Admin</title>
        <!-- Fav  Icon Link -->
        <link rel="shortcut icon" type="image/png" href="images/fav.png">
        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- themify icons CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- Animations CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- Main CSS -->
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/red.css" id="style_theme">
        <link rel="stylesheet" href="css/responsive.css">
        <!-- morris charts -->
        <link rel="stylesheet" href="charts/css/morris.css">
        <!-- jvectormap -->
        <link rel="stylesheet" href="css/jquery-jvectormap.css">

        <script src="js/modernizr.min.js"></script>
    </head>

    <body>
        <!-- Pre Loader -->
        <div class="loading">
            <div class="spinner">
                <div class="double-bounce1"></div>
                <div class="double-bounce2"></div>
            </div>
        </div>
        <!--/Pre Loader -->

        <div class="wrapper">

            <?php include './left-bar.php'; ?>
            <!-- Page Content -->

            <div id="content">
                <?php include './header.php'; ?>
                <!-- Breadcrumb -->
                <!-- Page Title -->
                <div class="row no-margin-padding">
                    <div class="col-md-6">
                        <h3 class="block-title">Quick Statistics</h3>
                    </div>
                    <div class="col-md-6">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="index.html">
                                    <span class="ti-home"></span>
                                </a>
                            </li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                <!-- /Page Title -->

                <!-- /Breadcrumb -->

                <!-- Main Content -->
                <div class="container-fluid">

                    <div class="row">
                        <!-- Widget Item -->
                        <div class="col-md-12">
                            <div class="widget-area-2 proclinic-box-shadow">
                                <?php
                                if ($success) {
                                    ?>
                                    <!-- Alerts-->
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong>Successfully Done!</strong> Please Check in Users List
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <?php
                                }
                                if ($error) {
                                    ?>

                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Oops !</strong> Please Try Again !
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                    </div>
                                    <!-- /Alerts--> 
                                    <?php
                                }
                                ?>

                                <h3 class="widget-title">Add User</h3>
                               <form action="register.php" method="post" class="formRegister">
               
                <table border="0" align="center" class="tblRegisterForm">
                    <tr>
                        <td><label for="txtFName">First Name: </label></td>
                        <td><input type="text" id="txtFName" name="txtFName" class="inputs" placeholder="Type here..." /></td>
                    </tr>

                    <tr>
                        <td><label for="txtLName">Last Name: </label></td>
                        <td><input type="text" id="txtLName" name="txtLName" class="inputs" placeholder="Type here..." /></td>
                    </tr>

                    <tr>
                        <td><label for="txtUsername">Username: </label></td>
                        <td><input type="text" id="txtUsername" name="txtUsername" class="inputs" placeholder="Type here..." /></td>
                    </tr>

                    <tr>
                        <td><label for="txtEmail">Email: </label></td>
                        <td><input type="text" id="txtEmail" name="txtEmail" class="inputs" placeholder="example@ex.com" /></td>
                    </tr>

                    <tr>
                        <td><label for="txtAddress">Address: </label></td>
                        <td><textarea style="resize: none" id="txtAddress" name="txtAddress" class="inputs" placeholder="Type here..."></textarea></td>
                    </tr>

                    <tr>
                        <td><label for="txtRegPassword">Password: </label></td>
                        <td><input type="password" id="txtRegPassword" name="txtPassword" class="inputs" placeholder="Must be longer than 6 characters" /></td>
                    </tr>

                    <tr>
                        <td><label for="txtRegConfPassword">Confirm Password: </label></td>
                        <td><input type="password" id="txtRegConfPassword" name="txtConfPassword" class="inputs" /></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="padding-top: 30px"><input type="checkbox" id="chkAgreement" name="chkAgreement" value="agree" /> <label for="chkAgreement"><small>I have read the user-agreement and I agree to it</small></label></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><input style="float: right" type="submit" name="btnRegister" id="btnRegister" value="Register" onclick="valRegister()"/></td>
                    </tr>
                    <tr>
                        <td colspan="2" <?php if ($loggedStatus) {
    echo("style='display: none;'");
} ?> style="padding-bottom: 20px"><a href="login.php" style="color: #222"><small>Have an account? Login</small></a></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <small style="color: #777">*By registering in to Villagehut.com, you are agreeing to our site's <a href="#" style="color: #999"> Terms and conditions</a> and our <a href="#" style="color: #999"> Privacy policy. </a></small>
                        </td>
                    </tr>
                </table>
            </form>

                            </div>
                        </div>
                        <!-- /Widget Item -->
                    </div>
                </div>
                <!-- /Main Content -->
            </div>
            <!-- /Page Content -->
        </div>
        <!-- Back to Top -->
        <a id="back-to-top" href="#" class="back-to-top">
            <span class="ti-angle-up"></span>
        </a>
        <!-- /Back to Top -->

        <!-- Jquery Library-->
        <script src="js/jquery-3.2.1.min.js"></script>
        <!-- Popper Library-->
        <script src="js/popper.min.js"></script>
        <!-- Bootstrap Library-->
        <script src="js/bootstrap.min.js"></script>
        <!-- morris charts -->
        <script src="charts/js/raphael-min.js"></script>
        <script src="charts/js/morris.min.js"></script>
        <script src="js/custom-morris.js"></script>

        <!-- Custom Script-->
        <script src="js/custom.js"></script>
    </body>

</html>