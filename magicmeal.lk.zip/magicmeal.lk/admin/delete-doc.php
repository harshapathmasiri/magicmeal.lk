<?php

include '../Class/Db.php';

$image = $_GET['img'];

$file1 = '../images/doctor/' . $image;
$file2 = '../images/doctor/thumb/' . $image;

unlink($file1);
unlink($file2);

$sql = "DELETE FROM `doctor` WHERE `image_name` =  '$image'";

$db = new DB();

if ($db->readQuery($sql)) {
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}

