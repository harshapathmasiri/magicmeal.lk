<?php

include '../includes/db.php';

$id = $_GET['id'];


$sql = "DELETE FROM `appointment` WHERE `id` =  '$id'";

$db = new DB();

if ($db->readQuery($sql)) {
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}

