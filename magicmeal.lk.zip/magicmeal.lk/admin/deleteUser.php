<?php

include '../includes/db.php';

$image = $_GET['img'];

$file1 = '../img/profile/' . $image;
$file2 = '../img/profile/thumb/' . $image;

unlink($file1);
unlink($file2);

$sql = "DELETE FROM `patient` WHERE `image_name` =  '$image'";

$db = new DB();

if ($db->readQuery($sql)) {
    header('Location: ' . $_SERVER['HTTP_REFERER']);
}

