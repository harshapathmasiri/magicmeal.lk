<?php
session_start();

include '../includes/db.php';
include '../functions.php';



if (!isset($_SESSION['user'])) {
    echo '<script>window.location = "login.php";</script>';
}
if ($_SESSION['user']) {

    $username = $_SESSION['user'];

    $sql = "SELECT * FROM admin WHERE username='$username'";

    $db = new DB();

    $result = $db->readQuery($sql);
    $row = mysqli_fetch_assoc($result);
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Magic Meal Admin | Home | Dashboard</title>
        <!-- Fav  Icon Link -->
        <link rel="shortcut icon" type="image/png" href="images/../images/Magic-Meal-Logo.png">
        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- themify icons CSS -->
        <link rel="stylesheet" href="css/themify-icons.css">
        <!-- Animations CSS -->
        <link rel="stylesheet" href="css/animate.css">
        <!-- Main CSS -->
        <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/red.css" id="style_theme">
        <link rel="stylesheet" href="css/responsive.css">
        <!-- morris charts -->
        <link rel="stylesheet" href="charts/css/morris.css">
        <!-- jvectormap -->
        <link rel="stylesheet" href="css/jquery-jvectormap.css">

        <script src="js/modernizr.min.js"></script>
    </head>

    <body>


        <div class="wrapper">

            <?php include './left-bar.php'; ?>
            <!-- Page Content -->

            <div id="content">
                <?php include './header.php'; ?>
                <!-- Breadcrumb -->
                <!-- Page Title -->
                <div class="row no-margin-padding">
                    <div class="col-md-6">
                        <h3 class="block-title">Quick Statistics</h3>
                    </div>
                    <div class="col-md-6">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="index.php">
                                    <span class="ti-home"></span>
                                </a>
                            </li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                </div>
                <!-- /Page Title -->

                <!-- /Breadcrumb -->
                <!-- Main Content -->
                <div class="container-fluid home">


                    <div class="row">
                        <!-- Widget Item -->
                        <div class="col-md-4">
                            <div class="widget-area proclinic-box-shadow color-red">
                                <div class="widget-left">
                                    <span class="ti-user"></span>
                                </div>
                                <div class="widget-right">
                                    <h4 class="wiget-title">Users</h4>
                                    <span class="numeric color-red">384</span>
                                    <p class="inc-dec mb-0"><span class="ti-angle-up"></span> +20% Increased</p>
                                </div>
                            </div>
                        </div>
                        <!-- /Widget Item -->
                        <!-- Widget Item -->
                        <div class="col-md-4">
                            <div class="widget-area proclinic-box-shadow color-green">
                                <div class="widget-left">
                                    <span class="ti-bar-chart"></span>
                                </div>
                                <div class="widget-right">
                                    <h4 class="wiget-title">Completed Orders</h4>
                                    <span class="numeric color-green">585</span>
                                    <p class="inc-dec mb-0"><span class="ti-angle-down"></span> -15% Decreased</p>
                                </div>
                            </div>
                        </div>
                        <!-- /Widget Item -->
                        <!-- Widget Item -->
                        <div class="col-md-4">
                            <div class="widget-area proclinic-box-shadow color-yellow">
                                <div class="widget-left">
                                    <span class="ti-money"></span>
                                </div>
                                <div class="widget-right">
                                    <h4 class="wiget-title">Arrived Orders</h4>
                                    <span class="numeric color-yellow">125</span>
                                    <p class="inc-dec mb-0"><span class="ti-angle-up"></span> +10% Increased</p>
                                </div>
                            </div>
                        </div>
                        <!-- /Widget Item -->
                    </div>

                    <div class="container-fluid home">

                      
                    </div>

                </div>
                <!-- /Main Content -->
            </div>
            <!-- /Page Content -->
        </div>
        <!-- Back to Top -->
        <a id="back-to-top" href="#" class="back-to-top">
            <span class="ti-angle-up"></span>
        </a>
        <!-- /Back to Top -->

        <!-- Jquery Library-->
        <script src="js/jquery-3.2.1.min.js"></script>
        <!-- Popper Library-->
        <script src="js/popper.min.js"></script>
        <!-- Bootstrap Library-->
        <script src="js/bootstrap.min.js"></script>
        <!-- morris charts -->
        <script src="charts/js/raphael-min.js"></script>
        <script src="charts/js/morris.min.js"></script>
        <script src="js/custom-morris.js"></script>

        <!-- Custom Script-->
        <script src="js/custom.js"></script>
        <script>
            $('.delete').click(function (e) {
                var r = confirm("Are you really want remove this Order?....");
                if (r) {
                    window.location.replace("deleteOrder.php?id=" + this.id);
                }
            });

        </script>
    </body>

</html>