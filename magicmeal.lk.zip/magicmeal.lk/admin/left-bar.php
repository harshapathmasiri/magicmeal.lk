<?php
$path = basename($_SERVER['REQUEST_URI'], '?' . $_SERVER['QUERY_STRING']);
?>


<!-- Sidebar -->
<nav id="sidebar" class="proclinic-bg">
    <div class="sidebar-header">
        <a href="./"><img src="../images/logo/logo.jpg" width="140px" height="130px" class="logo" alt="logo" style="margin-left: 30px"></a>
    </div>
    <ul class="list-unstyled components">

        <li <?php
        if ($path == "admin" || $path == "index.php") {
            echo 'class="active"';
        }
        ?>>
            <a href="./">
                <span class="ti-layout-menu-v"></span> Dashboard
            </a>
        </li>

        <li <?php
        if ($path == "addUser.php" || $path == "users.php") {
            echo 'class="active"';
        }
        ?>>
            <a href="#nav-patients" data-toggle="collapse" aria-expanded="false">
                <span class="ti-wheelchair"></span> Users
            </a>
            <ul class="collapse list-unstyled" id="nav-patients">
                <li>
                    <a href="addUser.php">Add User</a>
                </li>
                <li>
                    <a href="users.php">All Users</a>
                </li> 
            </ul>
        </li>
        <li <?php
        if ($path == "addOrder.php" || $path == "orders.php") {
            echo 'class="active"';
        }
        ?>>
            <a href="#nav-appointment" data-toggle="collapse" aria-expanded="false">
                <span class="ti-pencil-alt"></span> Orders
            </a>
            <ul class="collapse list-unstyled" id="nav-appointment">
                <li>
                    <a href="addOrder.php">Add Order</a>
                </li>
                <li>
                    <a href="orders.php">All Orders</a>
                </li> 
            </ul>
        </li>

        <li>
            <a href="./logout.php">
                <span class="ti-power-off"></span> Logout
            </a>
        </li>

    </ul>
    <div class="nav-help animated fadeIn">
        <h5><span class="ti-comments"></span> Need Help</h5>
        <h6>
            <span class="ti-mobile"></span> +94 77 241 7000</h6>
        <h6>
            <span class="ti-email"></span> harshapathmasiri@gmail.com</h6>
        <p class="copyright-text">Copy rights &copy; <?php echo date("Y") ?></p>
    </div>
</nav>
<!-- /Sidebar -->