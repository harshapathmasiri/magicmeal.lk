<?php session_start() ?>

<?php
include("includes/db.php");

$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
        if (isset($_SESSION["clientRow"])) {
            $sess_row = $_SESSION["clientRow"];
        }
    }
} else {
    $loggedStatus = 0;
}


$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);

$get_catName = "";
$get_sid = 0;
$get_sName = "";

$dbTable = "";
$dbIdColumn = "";
$db_sName = "";

$chk_sql = "";
$chk_output = 0;
$chk_row = "";

$minQty = 1;

if (isset($_GET["catName"]) && isset($_GET["sId"]) && isset($_GET["sName"])) {
    $get_catName = $_GET["catName"];
    $get_sid = $_GET["sId"];
    $get_sName = $_GET["sName"];


    switch ($get_catName) {
        case "Wedding halls";
            $dbTable = "tbl_wedding";
            $dbIdColumn = "wId";
            $minQty = 1;
            break;

        case "Catering";
            $dbTable = "tbl_catering";
            $dbIdColumn = "cId";
            $minQty = 100;
            break;

        case "Functional Needs";
            $dbTable = "tbl_fn";
            $dbIdColumn = "fnId";
            $minQty = 50;
            break;

        case "Lights/Stage Equipments";
            $dbTable = "tbl_lse";
            $dbIdColumn = "lseId";
            $minQty = 1;
            break;

        case "Stages/Huts/Tents";
            $dbTable = "tbl_sht";
            $dbIdColumn = "shtId";
            $minQty = 1;
            break;

        case "Music Instruments/Bands";
            $dbTable = "tbl_mi";
            $dbIdColumn = "miId";
            $minQty = 1;
            break;

        default;
            header("location:servWeddings.php");
    }

    if (!(is_numeric($get_sid))) {
        header("location:servWeddings.php");
    }


    /* Retrieving details to check and update fields */
    $chk_sql = "SELECT * FROM " . $dbTable . " WHERE " . $dbIdColumn . " = '$get_sid' AND catName = '$get_catName'";
    $chk_output = mysqli_query($conn, $chk_sql);

    if ($chk_output->num_rows > 0) {
        $chk_row = $chk_output->fetch_assoc();
        $db_sName = $chk_row["sName"];

        if ($db_sName != $get_sName) {
            mysqli_close($conn);
            header("location:servWeddings.php");
        }
    } else {
        mysqli_close($conn);
        header("location:servWeddings.php");
    }
} else {
    mysqli_close($conn);
    header("location:servWeddings.php");
}

/* Saving details */
$txtService = "";
$comboType = "";
$txtDate = "";
$txtNOD = "";
$txtOrderQty = "";
$txtOrderDeposite = "";
$monthArray = "";
$A = "";
$formatDate = "";

$sql = "";
$output = 0;
if (isset($_POST["btnOrderDetailsSub"])) {
    $username = $sess_row["username"];

    $txtService = $chk_row["sName"];
    $txtDate = $_POST["txtSelDate"];

    $monthArray = array("January" => "1", "February" => "2", "March" => "3", "April" => "4", "May" => "5", "June" => "6", "July" => "7", "August" => "8", "September" => "9", "October" => "10", "November" => "11", "December" => "12");
    $A = explode("/", $txtDate);
    $formatDate = trim($A[0]) . "-" . $monthArray[trim($A[1])] . "-" . trim($A[2]);

    $txtNOD = $_POST["txtNOD"];
    $txtOrderQty = $_POST["txtOrderQty"];
    $txtOrderDeposite = $_POST["txtTempPrice1"];

    if ($get_catName != "Stages/Huts/Tents") {
        $comboType = "NA";
    } else {
        $comboType = $_POST["comboType"];
    }


    $sql = "INSERT INTO tbl_transaction(username,catName,sName,orderDate,qtyOrd,noOfDays,type,price) VALUES('$username','$get_catName','$txtService','$formatDate','$txtOrderQty','$txtNOD','$comboType','$txtOrderDeposite')";

    $output = mysqli_query($conn, $sql);
    if ($output) {
        
    } else {
        echo("Error " . $txtOrderDeposite);
    }
}


/* Saving to cart */
$txtComboTypeCart = "";
if (isset($_POST["btnODAddToCart"])) {
    if ($get_catName != "Stages/Huts/Tents") {
        $txtComboTypeCart = "N/A";
    } else {
        $txtComboTypeCart = $_POST["comboType"];
    }
    if (isset($_COOKIE["vhCart"])) {
        setcookie("vhCart", $_COOKIE["vhCart"] . "+" . $chk_row[$dbIdColumn] . "+" . $chk_row["catName"] . "+" . $chk_row["sName"] . "+" . $_POST["txtSelDate"] . "+" . $txtComboTypeCart . "+" . $_POST["txtOrderQty"], time() + 3600);
    } else {
        setcookie("vhCart", $chk_row[$dbIdColumn] . "+" . $chk_row["catName"] . "+" . $chk_row["sName"] . "+" . $_POST["txtSelDate"] . "+" . $txtComboTypeCart . "+" . $_POST["txtOrderQty"], time() + 3600);
    }

    header("location:cart.php");
}


mysqli_close($conn);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/style_services.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/calendar.css" />


        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Service</title>

        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/PINK-S.png"/>

        <script src="js/script.js" type="text/javascript"></script>

    </head>

    <body onLoad="priceAccordingToQty()">
        <?php
        include_once("includes/navbar.php");
        ?>


        <div class="container2">
            <div class="divOrderForm">
                <h1 class="pPickDate">Order Details</h1>
                <form action="" class="orderForm" method="post" name="orderForm">


                    <div class="orderedDates" style="display: none; visibility: hidden; opacity: 0;">
                        <?php
                        $conn1 = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);
                        $date_sql = "SELECT orderDate FROM tbl_transaction WHERE sName = '$get_sName'";
                        $date_output = mysqli_query($conn1, $date_sql);

                        $index = 0;
                        if ($date_output->num_rows > 0) {
                            while ($date_row = $date_output->fetch_assoc()) {
                                $orderedDates = $date_row["orderDate"];

                                echo('
									<input type="text" class="txtClsOrderedDates" id="txtOrderedDates' . $index . '" name="txtOrderedDates' . $index . '" value="' . $orderedDates . '" />
								');
                                $index++;
                            }
                        }
                        ?>
                    </div>


                    <table border="0" align="center" class="tblOrderForm">
                        <tr>
                            <td>
                                <label for="txtCatName">Service: </label><br />
                                <input type="text" name="txtCatName" id="txtCatName" style="display: none; opacity: 0; visibility: hidden;" value="<?php echo($get_catName); ?>" readonly/>
                                <input type="text" name="txtService" id="txtService" placeholder="Please Select A Service" disabled="disabled" value="<?php echo($chk_row["sName"]) ?>" /><br /><br />
                            </td>
                            <td></td>
                        </tr>
                        <tr <?php
                        if ($get_catName == "Stages/Huts/Tents") {
                            echo("");
                        } else {
                            echo("style='display:none;'");
                        }
                        ?>>
                            <td>				
                                <label for="comboType">Type: </label><br />
                                <select id="comboType" name="comboType" onChange="priceAccordingToType()">
                                    <option selected="selected">Select</option>
                                    <?php
                                    if ($get_catName == "Stages/Huts/Tents") {
                                        $B = explode(",", $chk_row["type"]);
                                        for ($i = 0; $i < sizeof($B); $i++) {
                                            echo('
											<option>' . trim($B[$i]) . '</option>
										');
                                        }
                                    }
                                    ?>
                                </select><br /><br />
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td>				
                                <label for="txtDate">Reservation Date: </label><br />
                                <input type="text" name="txtSelDate" id="txtSelDate" placeholder="Please Select A Booking Date" onChange="priceAccordingToQty()" readonly/><br /><br />
                                <?php
                                include_once("includes/calendar.php");
                                ?>
                            </td>
                            <td>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <br />
                                <label for="txtOrderQty">Quantity:</label><br />
                                <select name="txtOrderQty" id="txtOrderQty" onChange="priceAccordingToQty()">
                                    <?php
                                    for ($i = $minQty - 1; $i < $chk_row["qty"]; $i++) {
                                        echo(
                                        '<option>' . ($i + 1) . '</option>'
                                        );
                                    }
                                    ?>
                                </select>
                                <br /><br />
                            </td>
                            <td class="tblOrderFormTdPding">
                                <input type="submit" name="btnOrderDetailsSub" id="btnOrderDetailsSub" value="Deposite now" onMouseOver="priceAccordingToQty()" onClick="orderValidate()" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label for="txtOrderDeposite">Deposite:</label><br />
                                <input type="text" name="txtOrderDeposite" id="txtOrderDeposite" value="<?php
                                if ($get_catName == 'Stages/Huts/Tents') {
                                    echo("Please select a type");
                                } else {
                                    echo(number_format($chk_row['price']));
                                }
                                ?>" readonly/><br /><br />

                                <input type="text" name="txtTempPrice" id="txtTempPrice" style="display: none; opacity: 0; visibility: hidden;" value="<?php echo($chk_row["price"]); ?>" />
                                <input type="text" name="txtTempPrice1" id="txtTempPrice1" style="display: none; opacity: 0; visibility: hidden;" value="" />

                            </td>
                            <td class="tblOrderFormTdPding">
                                <input type="submit" name="btnODAddToCart" id="btnODAddToCart" value="Add to cart" />
                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>



        <?php
        include_once("includes/footer.php");
        ?>

        <script type="text/javascript">
            calendar();
        </script>

    </body>
</html>