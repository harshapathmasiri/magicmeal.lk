<?php session_start() ;

if(isset($_GET['clear'])){
    $_SESSION['items']='';
    $_SESSION['prices']='';
    $items = array();
    $prices = array();


}

?>

<?php
include("includes/db.php");

$loggedStatus = false;
$clientRow = "";

if (isset($_SESSION["clientLogin"]) && isset($_SESSION["clientRow"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = true;
        $clientRow = $_SESSION["clientRow"];
        $uName = $clientRow["username"];
    }
} else {
    $loggedStatus = false;
}


//Clear individual item
$clickedIndex = 0;
$arrayStart = 0;
$arrayEnd = 0;
$cookieString = "";
if (isset($_POST["btnClearItem"]) && $_COOKIE["vhCart"]) {
    $C = explode("+", $_COOKIE["vhCart"]);
    $itemCount = $_POST["itemCount"];
    $clickedIndex = $_POST["btnClearItem"];
    $arrayStart = $clickedIndex * 6;
    $arrayEnd = $arrayStart + 5;
    for ($l = 0; $l < sizeof($C); $l++) {
        if ($l == $arrayStart && $l != $arrayEnd + 1) {
            $arrayStart++;
            continue;
        } else {
            if ($l == sizeof($C) - 1 || (($clickedIndex == $itemCount - 1) && ($l == ($itemCount * 6) - 7))) {
                $cookieString .= $C[$l];
            } else {
                $cookieString .= $C[$l] . "+";
            }
        }
    }

    setcookie("vhCart", $cookieString, time() + 3600);
    header("location:cart.php");
}


//Update cart
$qty = "";
$qtyIndex = 5;
$cookieString1 = "";
if (isset($_POST["btnSCartUpdate"]) && isset($_COOKIE["vhCart"])) {
    $C = explode("+", $_COOKIE["vhCart"]);
    for ($m = 0; $m < sizeof($C) / 6; $m++) {
        $qty = $_POST["txtOrderQty" . $m];
        $C[$qtyIndex] = $qty;
        $qtyIndex += 6;
    }

    for ($m = 0; $m < sizeof($C); $m++) {
        if ($m != sizeof($C) - 1) {
            $cookieString1 .= $C[$m] . "+";
        } else {
            $cookieString1 .= $C[$m];
        }
    }
    setcookie("vhCart", $cookieString1, time() + 3600);
    header("location:cart.php");
}


//Deposit now button
$conn1 = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);
$sql1 = "";
$output1 = "";
$ErrorLog = "<p class='hidden'></p>";
$done1 = "";
$monthArray = array("January" => "1", "February" => "2", "March" => "3", "April" => "4", "May" => "5", "June" => "6", "July" => "7", "August" => "8", "September" => "9", "October" => "10", "November" => "11", "December" => "12");

$price = "";
$oDate = "";

$dateIndex1 = 3;
$typeIndex1 = 4;
$qtyIndex1 = 5;
$catNameIndex1 = 1;
$sNameIndex1 = 2;
$idIndex1 = 0;


if (isset($_POST["btnSCartDNow"]) && isset($_COOKIE["vhCart"])) {
    if ($loggedStatus) {
        $C = explode("+", $_COOKIE["vhCart"]);
        for ($n = 0; $n < sizeof($C) / 6; $n++) {
            $price = $_POST["txtTempPrice" . $n];

            $D = explode("/", $C[$dateIndex1]);
            $D[1] = $monthArray[trim($D[1])];
            for ($o = 0; $o < sizeof($D); $o++) {
                if ($o == sizeof($D) - 1) {
                    $oDate .= trim($D[$o]);
                } else {
                    $oDate .= trim($D[$o]) . "-";
                }
            }

            $sql1 = "INSERT INTO tbl_transaction(username,catName,sName,price,orderDate,qtyOrd,type) VALUES('$uName','$C[$catNameIndex1]','$C[$sNameIndex1]','$price','$oDate','$C[$qtyIndex1]','$C[$typeIndex1]')";

            if ($output1 = mysqli_query($conn1, $sql1)) {
                
            } else {
                $done1 = "Error inserting values";
                echo($done1 . "<br>" . $sql1);
            }

            $dateIndex1 += 6;
            $typeIndex1 += 6;
            $qtyIndex1 += 6;
            $catNameIndex1 += 6;
            $sNameIndex1 += 6;
            $idIndex1 += 6;
            $oDate = "";
        }

        if ($done1 == "") {
            header("location:purchaseHistory.php");
        } else {
            
        }
    } else {
        $ErrorLog = "<p class='errorLog'>Please Login to continue!</p>";
    }
}


//Delete all
if (isset($_POST["btnCartClearAll"])) {
    setcookie("vhCart", "", time() - 3600);
    header("location:cart.php");
}
?>
<?php 
session_start();
$items = array();
$prices = array();

if(isset($_SESSION['items'])){
   $items= explode(",",$_SESSION['items']) ;
   $prices= explode(",",$_SESSION['prices']) ;   
      
}

 ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/style_cart.css" />

        <script src="js/script.js" type="text/javascript"></script>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>My Cart | Magic Meal</title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body onLoad="cartOnLoad()">

<?php
include_once("includes/navbar.php");
?>

        <div class="container">
            <h1 class="myCartTitle">Magic Meal Food Cart</h1>	
            <br />



            <div >
                <table width="600">
                      <?php 
                        if(count($items)>0)
                        {
                             ?>
                                <tr>
                                    <th colspan="2"><center>Cart</center></th>

                                </tr>

                                <?php


                           $k=0;
                            foreach ($items as $key => $item) {
                                ?>
                                <tr>
                                    <td style="padding: 6px"><?php echo $item; ?></td>
                                    <td style="padding: 6px"><?php echo $prices[$k]; ?></td>

                                </tr>

                                <?php

                                $k++;
                            }
                            ?>
                                <tr>
                                    <td colspan="2"><center>
                                        <a href="?clear">Clear Cart</a></center>

                                  

                                </tr>

                                <?php

                        }else{
                            ?>
                                <tr>
                                    <td colspan="2"><center>No Items</center></td>

                                </tr>

                                <?php


                        }                
                         ?>
                </table>
            </div>
            <div class="myCartPage">
                <form action="" method="post" class="formSCart">
                    <table border="0" align="center" class="tblShoppingCart">
<?php
$conn = "";
$sql = "";
$output = "";
$row = "";
$dbTable = "";
$dbIdColumn = "";
$i = "";
if (isset($_COOKIE["vhCart"])) {

    $conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);


    echo('                    
								<tr>
									<th>
										<p class="sCartHead">Service</p>
									</th>
									<th>
										<p class="sCartHead">Reservation Date</p>
									</th>
									<th>
										<p class="sCartHead">QTY</p>
									</th>
									<th>
										<p class="sCartHead">Type</p>
									</th>
									<th>
										<p class="sCartHead">Price</p>
									</th>
									<th>
									</th>
								</tr>
							');

    $A = explode("+", $_COOKIE["vhCart"]);

    $dateIndex = 3;
    $typeIndex = 4;
    $qtyIndex = 5;
    $catNameIndex = 1;
    $sNameIndex = 2;
    $idIndex = 0;

    $typeMultipliedValue = 1;
    $minQty = 1;

    for ($i = 0; $i < sizeof($A) / 6; $i++) {

        switch ($A[$catNameIndex]) {
            case "Buffet";
                $dbTable = "tbl_wedding";
                $dbIdColumn = "wId";
                $typeMultipliedValue = 1;
                $minQty = 1;
                break;

            case "Catering";
                $dbTable = "tbl_catering";
                $dbIdColumn = "cId";
                $typeMultipliedValue = 1;
                $minQty = 100;
                break;

            case "Special Meals";
                $dbTable = "tbl_fn";
                $dbIdColumn = "fnId";
                $typeMultipliedValue = 1;
                $minQty = 50;
                break;

            case "Sea Foods";
                $dbTable = "tbl_lse";
                $dbIdColumn = "lseId";
                $typeMultipliedValue = 1;
                $minQty = 1;
                break;

            case "Indian Foods";
                $dbTable = "tbl_sht";
                $dbIdColumn = "shtId";
                $B = explode("*", $A[$typeIndex]);
                for ($k = 0; $k < sizeof($B); $k++) {
                    $typeMultipliedValue *= $B[$k];
                }
                $minQty = 1;
                break;

            case "Chinese Foods";
                $dbTable = "tbl_mi";
                $dbIdColumn = "miId";
                $typeMultipliedValue = 1;
                $minQty = 1;
                break;

            default;
                header("location:servWeddings.php");
        }

        $sql = "SELECT * FROM " . $dbTable . " WHERE " . $dbIdColumn . " = $A[$idIndex]";
        $output = mysqli_query($conn, $sql);

        if ($output->num_rows > 0) {
            while ($row = $output->fetch_assoc()) {
                echo('
											<tr>
												<td>
													<p id="paraServiceNameC' . $i . '" class="sCartAdded">' . $row["catName"] . ' > ' . $row["sName"] . '</p>
												</td>
												<td>
													<p class="sCartAdded">' . $A[$dateIndex] . '</p>
												</td>
												<td>
													<select name="txtOrderQty' . $i . '" id="txtOrderQty' . $i . '" class="ClassTxtOrderQty" onChange="priceAccordingToQtyCart(this.id)">');

                for ($j = $minQty - 1; $j < $row["qty"]; $j++) {
                    if ($A[$qtyIndex] == $j + 1) {
                        echo(
                        '<option selected="selected">' . ($j + 1) . '</option>'
                        );
                    } else {
                        echo(
                        '<option>' . ($j + 1) . '</option>'
                        );
                    }
                }

                echo('</select>
												</td>
												<td>
													<p class="sCartAdded" id="txtTypeCart' . $i . '">' . $A[$typeIndex] . '</p>
												</td>
												<td>
													<p class="sCartAdded" id="pricePara' . $i . '"></p>
													<input type="text" class="hidden" name="txtTempPrice' . $i . '" id="txtTempPrice' . $i . '" value="' . $A[$qtyIndex] * $typeMultipliedValue * $row["price"] . '"/>
													<input type="text" class="hidden" name="txtTempPricePerUnit' . $i . '" id="txtTempPricePerUnit' . $i . '" value="' . $row["price"] . '"/>										</td>
												<td>
													<img src="images/icons/bin1.png" alt="Delete button" width="25" id="imgBin' . $i . '" onmouseover="btnDeleteMOV(this.id)" onmouseout="btnDeleteMOU(this.id)" onClick="cartClearItemClicked(' . $i . ')"/>
													<input type="submit" class="hidden" id="btnClearItem' . $i . '" name="btnClearItem" value="' . $i . '"/>
												</td>
											</tr>
										');
            }
        }

        $dateIndex += 6;
        $typeIndex += 6;
        $qtyIndex += 6;
        $catNameIndex += 6;
        $sNameIndex += 6;
        $idIndex += 6;
        $typeMultipliedValue = 1;
    }
    echo('
								<tr>
									<td>
									</td>

									<td>
									</td>

									<td>
									</td>

									<td>
										<p class="sCartAdded">SubTotal</p>
									</td>

									<td>
										<p class="sCartAdded" id="cartTotal"></p>
									</td>

									<td>
										<input type="submit" id="btnCartClearAll" name="btnCartClearAll" value="Delete Cart"/>
									</td>
								</tr>
							');

    mysqli_close($conn);
} else {
    echo('
								<p class="emptyCart"></p>
							');
}
echo('</table>
					<input type="text" class="hidden" id="itemCount" name="itemCount" value="' . $i . '"/>');
?>

                        <input type="submit" id="btnSCartUpdate" name="btnSCartUpdate" value="Update cart"/>
                        <p class="updateNotice" id="idUpdateNotice">*Please update the cart manually if this process takes too long >></p>

                        <a type="submit" id="btnSCartDNow" name="btnSCartDNow" href="https://192.168.1.140:8888/" target="_blank" value=""/>Talk with Chef</a>

                </form>
                <a type="submit" id="btnSCartDNow" name="btnSCartDNow" href="http://192.168.1.120/doc/page/login.asp?_1693502745020" target="_blank" value=""/>Live Cooking View</a>
            </div>
        </div> 

<?php



include_once("includes/footer.php");
?>

        <script type="text/javascript">

        </script>

    </body>
</html>