<?php session_start() ?>

<?php
$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientRow"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/style_register.css" />
        <link rel="stylesheet" type="text/css" href="css/style_index.css" />

        <script src="js/script.js" type="text/javascript"></script>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Contact Us | Magic Meal</title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body>

        <?php
        include_once("includes/navbar.php");
        ?>

        <div class="container" style="margin-bottom: -100px">
           <iframe src="form/contact.php" style="height:600px;width:100%;border-width:0px"></iframe>

        </div>

        <div class="content1" style="margin-left: -0.5px">
            <table align="center" border="0" class="tblServCards">
                <tr>

                    <td style="padding-right: 50px; padding-left: 90px">
                        <div class="weddings sCard">
                            <div class="servCardOverlay">
                            </div>
                            <div class="wedImg img">
                                <img src="images/icons/tp.jpg" />
                                <p class="servCardTitle">Hot - Line</p>
                            </div>

                            <div class="servCardDesc" style="padding-top: 50px">
                                <p align="center">+94 77 241 7000</p>
                            </div>
                        </div>
                    </td>			

                    <td style="padding-right: 50px ">
                        <div class="catering sCard">
                            <div class="servCardOverlay">
                            </div>
                            <div class="caterImg img">
                                <img src="images/icons/mail.jpg" />
                                <p class="servCardTitle">E - Mail</p>
                            </div>

                            <div class="servCardDesc" style="padding-top: 50px">
                                <p align="center">harshapathmasiri@gmail.com</p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="Functions sCard">
                            <div class="servCardOverlay">
                            </div>
                            <div class="functionsImg img">
                                <img src="images/icons/location.jpg" />
                                <p class="servCardTitle">Address</p>
                            </div>

                            <div class="servCardDesc" style="padding-top: 20px">
                                <p align="center">No: 141, </br>Bothale Ihalagama, Ambepussa </br></p>
                            </div>
                        </div>
                    </td>

                </tr>
            </table>
        </div>

        <?php
        include_once("includes/footer.php");
        ?>

        <script type="text/javascript">

        </script>

    </body>
</html>