-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 26, 2020 at 07:58 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `villagehut`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `first_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `contact_no` int(20) NOT NULL,
  `address` longtext COLLATE utf8_unicode_ci NOT NULL,
  `birthday` date NOT NULL,
  `username` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `first_name`, `last_name`, `contact_no`, `address`, `birthday`, `username`, `password`) VALUES
(1, 'olash', 'gimhan', 710158573, 'Aparekka, Matara', '1996-03-21', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_catering`
--

CREATE TABLE `tbl_catering` (
  `cId` int(11) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `sName` varchar(300) NOT NULL,
  `price` float NOT NULL,
  `welDrink` varchar(1000) NOT NULL,
  `starters` varchar(1000) NOT NULL,
  `mainC` varchar(10000) NOT NULL,
  `dessert` varchar(1000) NOT NULL,
  `other` varchar(1000) NOT NULL,
  `image` varchar(500) NOT NULL,
  `cardDes` varchar(500) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_catering`
--

INSERT INTO `tbl_catering` (`cId`, `catName`, `sName`, `price`, `welDrink`, `starters`, `mainC`, `dessert`, `other`, `image`, `cardDes`, `qty`) VALUES
(4, 'Catering', 'Platinum', 4000, 'Orange juice, Papaya juice, Mix fruit juice, iced coffee', 'Chicken BBQ, Hot fried chicken, Cheese balls, Sea food BBQ', 'Fried Rice, Biriyani, White rice, Noodles, String hoppers,, Fried chicken, Stir Fried Chilli Chicken, Sea food, Pork, Beef, Sausages, Egg,, Eight randomly choosen vegetables curries will be served., Cashew nut curry, Pickle, Chillie paste', 'Ice cream, Watalappan, Biscuit pudding, Plum pudding, Fruit salad, Caramel pudding, Chocolate lava cake', 'Chicken or vegetable soup, Appetite foods are served on request', 'C1.jpg', 'The perfect menu that let you dine like a king.', 1000),
(5, 'Catering', 'Gold', 2000, 'Orange juice, Papaya juice, iced coffee', 'Chicken BBQ, Sea food BBQ', 'Fried Rice, Biriyani, White rice, Noodles,, Fried chicken, Sea food (*limited to two items), Pork or beef, Egg,, Six randomly choosen vegetables curries will be served., Cashew nut curry, Pickle, Chillie paste', 'Ice cream, Watalappan, Biscuit pudding, Plum pudding, Fruit salad', 'Chicken or vegetable soup', 'C2.jpg', 'The balanced menu with delicious food.', 1000),
(6, 'Catering', 'Silver', 1350, 'Orange juice, iced coffee', 'Deviled chicken, Deviled fish', 'Fried Rice, Biriyani, White rice,, Roasted chicken, Fish, Pork or beef, Egg,, Four randomly choosen vegetables curries will be served., Mushroom curry, Cashew nut curry, Pickle, Chillie paste', 'Ice cream, Watalappan, Fruit salad', 'Deviled chickpeas with mushroom', 'C3.jpg', 'Serve your guests with delicious Sri Lankan foods.', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_client`
--

CREATE TABLE `tbl_client` (
  `cId` int(11) NOT NULL,
  `fName` varchar(300) NOT NULL,
  `lName` varchar(300) NOT NULL,
  `username` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_client`
--

INSERT INTO `tbl_client` (`cId`, `fName`, `lName`, `username`, `email`, `address`, `password`) VALUES
(16, 'Suneth', 'Thotagamuwa', 'twsuneth', 'twsuneth@gmail.com', 'Address', 'a80b555bae660c5a7d6fac26ff87da9e'),
(17, 'hkghm', 'mghmgh', 'uname', 'biscket3000@gmail.com', 'vbnvfngfng', 'a80b555bae660c5a7d6fac26ff87da9e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fn`
--

CREATE TABLE `tbl_fn` (
  `fnId` int(11) NOT NULL,
  `sName` varchar(300) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `Welcome Drink` varchar(100) NOT NULL,
  `Starters` varchar(100) NOT NULL,
  `Main Course` varchar(300) NOT NULL,
  `Dessert` varchar(200) NOT NULL,
  `price` float NOT NULL,
  `image` varchar(500) NOT NULL,
  `cardDes` varchar(500) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_fn`
--

INSERT INTO `tbl_fn` (`fnId`, `sName`, `catName`, `Welcome Drink`, `Starters`, `Main Course`, `Dessert`, `price`, `image`, `cardDes`, `qty`) VALUES
(3, 'Modern', 'Functional Needs', 'Orange juice, Iced cofee, Hot chocolate drink', 'Chicken BBQ, Hot fried chicken, Cheese balls, Sea food BBQ', 'Fried Rice, Biriyani, White rice, Noodles, String hoppers, Fried chicken, Chicken, Sea food, Pork, Beef, Sausages, Meat balls, Egg, Cashew nut curry, Pickle, Chillie paste', 'Ice cream, Watalappan, Biscuit pudding, Plum pudding, Fruit salad, Caramel pudding, Chocolate lava cake', 3500, 'FN1.jpg', 'The perfect menu that let you dine like a king.', 2000),
(4, 'Rural', 'Functional Needs', 'Herbal Green Porridge Drink', 'Fried fish', 'Red rice, White rice, Roasted chicken, Fish, Egg, \r\n\r\nEight randomly choosen vegetables curries will be served, \r\nMushroom curry, Cashew nut curry, Pickle, Chillie paste', 'Fruit salad, Watalappan, Curd and Honey', 2000, 'FN2.jpg', 'The perfect menu that let you dine like a villager.', 2000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_lse`
--

CREATE TABLE `tbl_lse` (
  `lseId` int(11) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `sName` varchar(300) NOT NULL,
  `price` float NOT NULL,
  `dimension` varchar(100) NOT NULL,
  `watt` varchar(100) NOT NULL,
  `color` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL,
  `cardDes` varchar(500) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_lse`
--

INSERT INTO `tbl_lse` (`lseId`, `catName`, `sName`, `price`, `dimension`, `watt`, `color`, `image`, `cardDes`, `qty`) VALUES
(2, 'Lights/Stage Equipments', 'Sodium Flash Light', 1000, '12*12', '100W', 'Sodium yellow', 'LSE1.jpg', 'High wattage Sodium lights for rent with wide range clear distance.', 25),
(3, 'Lights/Stage Equipments', 'Moving Head Light', 2500, '6*6*12', '30W', 'Multi colored', 'LSE2.jpg', 'Decorate your special occasion with beautiful lights.', 30),
(4, 'Lights/Stage Equipments', 'Color Wash', 4000, '4*3*36', '40W', 'Multi colored', 'LSE3.jpg', 'Color washes are perfect for blending colors to suit the occasion.', 10),
(5, 'Lights/Stage Equipments', 'Spot Light', 500, '3*6', '20W', 'Multi colored', 'LSE4.jpg', 'Ideal to highlight a person or an object.', 100);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mi`
--

CREATE TABLE `tbl_mi` (
  `miId` int(11) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `sName` varchar(300) NOT NULL,
  `price` float NOT NULL,
  `tech` varchar(100) NOT NULL,
  `speakers` varchar(500) NOT NULL,
  `duration` float NOT NULL,
  `image` varchar(500) NOT NULL,
  `cardDes` varchar(500) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_mi`
--

INSERT INTO `tbl_mi` (`miId`, `catName`, `sName`, `price`, `tech`, `speakers`, `duration`, `image`, `cardDes`, `qty`) VALUES
(3, 'Music Instruments/Bands', 'Plastic', 200, 'Automatic', 'Tables, Chair covers(as your wish), Table clothes, 10 extra chairs', 24, 'MIB1.jpg', 'Enjoy a small or \r\n big function with plastic decorated chairs.', 1000),
(4, 'Music Instruments/Bands', 'Steel', 150, 'Manual', 'Tables, Table clothes(as your wish), 5 extra chairs', 24, 'MIB2.jpg', 'Fill your function or trip with sweet steel foldable chairs.', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_qanda`
--

CREATE TABLE `tbl_qanda` (
  `qId` int(11) NOT NULL,
  `question` varchar(300) NOT NULL,
  `name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `answer` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_qanda`
--

INSERT INTO `tbl_qanda` (`qId`, `question`, `name`, `email`, `answer`) VALUES
(2, 'When are you open?', 'suneth', 'suneth@gmail.com', NULL),
(3, 'Can we pay on delivery?', 'derick', 'derick@gmial.com', NULL),
(4, 'Are there any discounts available?', 'Mark', 'mark@gmail.com', NULL),
(5, 'Do you guys have any showrooms?', 'Kelvin', 'kelvin@gmail.com', NULL),
(6, 'Is the delivery island wide?', 'Harry', 'harry@gmail.com', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sc`
--

CREATE TABLE `tbl_sc` (
  `scId` int(11) NOT NULL,
  `catName` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `sName` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `price` float NOT NULL,
  `mainC` varchar(8000) COLLATE utf8_unicode_ci NOT NULL,
  `other` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `cardDes` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_sc`
--

INSERT INTO `tbl_sc` (`scId`, `catName`, `sName`, `price`, `mainC`, `other`, `image`, `cardDes`, `qty`) VALUES
(1, 'Shipboard catering', 'Platinum', 4000, 'Fried Rice\r\nBiriyani\r\nWhite rice\r\nNoodles\r\nString hoppers\r\n\r\nFried chicken\r\nStir Fried Chilli Chicken\r\nSea food\r\nPork\r\nBeef\r\nSausages\r\nEgg\r\n\r\nEight randomly choosen vegetables curries will be served.\r\nCashew nut curry\r\nPickle\r\nChillie paste', 'Chicken or vegetable soup\r\nAppetite foods are served on request', '', 'The perfect menu that let you dine like a king.', 2000),
(2, 'Shipboard catering', 'Gold', 2000, 'Fried Rice\r\nBiriyani\r\nWhite rice\r\nNoodles\r\n\r\nFried chicken\r\nSea food (*limited to two items)\r\nPork or beef\r\nEgg\r\n\r\nSix randomly choosen vegetables curries will be served.\r\nCashew nut curry\r\nPickle\r\nChillie paste', 'Chicken or vegetable soup', '', 'The balanced menu with delicious food.', 2000),
(3, 'Shipboard catering', 'Drink', 1500, '', '', '', 'Serve your guests with delicious Sri Lankan drinks.', 2000);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_serv_details`
--

CREATE TABLE `tbl_serv_details` (
  `sId` int(11) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `image` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sht`
--

CREATE TABLE `tbl_sht` (
  `shtId` int(11) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `sName` varchar(300) NOT NULL,
  `capacity` int(11) NOT NULL,
  `decoration` varchar(300) NOT NULL,
  `type` varchar(500) NOT NULL,
  `price` float NOT NULL,
  `image` varchar(500) NOT NULL,
  `cardDes` varchar(500) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_sht`
--

INSERT INTO `tbl_sht` (`shtId`, `catName`, `sName`, `capacity`, `decoration`, `type`, `price`, `image`, `cardDes`, `qty`) VALUES
(3, 'Stages/Huts/Tents', 'Summer Huts', 7, 'Customizable according to the type of function.', '5*5', 100, 'SHT2.jpg', 'Partying with friends? Enjoy the moment under the sun.', 20),
(4, 'Stages/Huts/Tents', 'Parabolic Huts', 25, 'Customizable according to the type of function.', '10*30, 10*40, 10*50', 25, 'SHT3.jpg', 'Parabolic huts are the best match for a large crowd.', 20);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaction`
--

CREATE TABLE `tbl_transaction` (
  `phId` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `sName` varchar(300) NOT NULL,
  `price` float NOT NULL,
  `orderDate` date NOT NULL,
  `qtyOrd` int(11) NOT NULL,
  `type` varchar(300) DEFAULT NULL,
  `transactionDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_transaction`
--

INSERT INTO `tbl_transaction` (`phId`, `username`, `catName`, `sName`, `price`, `orderDate`, `qtyOrd`, `type`, `transactionDate`) VALUES
(24, 'twsuneth', 'Stages/Huts/Tents', 'Stages', 6000, '2018-05-31', 1, '10*30', '2018-05-22 08:20:59'),
(25, 'twsuneth', 'Functional Needs', 'Chairs', 1000, '2018-05-26', 50, 'N/A', '2018-05-22 08:20:59'),
(26, 'twsuneth', 'Music Instruments/Bands', 'One Man Music Band', 10000, '2018-05-31', 1, 'N/A', '2018-05-22 08:20:59'),
(27, 'twsuneth', 'Lights/Stage Equipments', 'Moving Head Light', 50000, '2018-05-21', 20, 'N/A', '2018-05-22 08:20:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_wedding`
--

CREATE TABLE `tbl_wedding` (
  `wId` int(11) NOT NULL,
  `sName` varchar(300) NOT NULL,
  `catName` varchar(300) NOT NULL,
  `nos` varchar(150) NOT NULL,
  `theme` varchar(300) NOT NULL,
  `ac` varchar(20) NOT NULL,
  `bar` varchar(20) NOT NULL,
  `wdescription` varchar(500) NOT NULL,
  `price` float NOT NULL,
  `image` varchar(500) NOT NULL,
  `cardDes` varchar(500) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_wedding`
--

INSERT INTO `tbl_wedding` (`wId`, `sName`, `catName`, `nos`, `theme`, `ac`, `bar`, `wdescription`, `price`, `image`, `cardDes`, `qty`) VALUES
(26, 'Hot', 'Wedding halls', 'Fried Fish, Prawns, Boiled Vegetables, Sausages, Vodka or Whisky', 'Premium', 'Yes', 'Yes', 'This type includes fried fish or fried meats, prawns or meat balls, sausages, vodka or whiskey, boiled vegetables as your wish. This is our most expensive seat - back catering type. You can pay at your destination.', 2500, 'WH2.jpg', 'Hot, is one of our most expensive Seat - Back Catering type.', 2000),
(27, 'Vegetarian', 'Wedding halls', 'Boiled Carrots, Boiled Beans, Vegetable Salad, Vegetable Chopsy, Cabbage Flowers, Cool Drink', 'Modern/ Teen/ Stylish', 'Yes', 'No', 'This type includes boiled carrots, boiled beans, vegetable salad, vegetable chopsy and cool drink as your wish. This is our one and only vegetarian seat - back catering type. You can pay at your destination.', 2000, 'WH1.jpg', 'Vegetarian, is our only vegetarian seat - back catering type.', 2000),
(28, 'Normal', 'Wedding halls', 'Fish or Meats, Boiled Vegetables, Soft Drinks or Beer, Curd or Ice Cream', 'Charming/ Chill', 'Yes', 'Yes', 'This type includes Fish or meats, sausages or meat balls, boiled vegetables, soft drinks or beer curd or ice cream as your wish. This is most suitable for a person who eats both meats and vegetables. You can pay at your destination.', 2200, 'WH3.jpg', 'Normal, is most suitable for a person who eats both meats and vegetables.', 2000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_catering`
--
ALTER TABLE `tbl_catering`
  ADD PRIMARY KEY (`cId`,`catName`,`sName`);

--
-- Indexes for table `tbl_client`
--
ALTER TABLE `tbl_client`
  ADD PRIMARY KEY (`cId`);

--
-- Indexes for table `tbl_fn`
--
ALTER TABLE `tbl_fn`
  ADD PRIMARY KEY (`fnId`,`sName`,`catName`);

--
-- Indexes for table `tbl_lse`
--
ALTER TABLE `tbl_lse`
  ADD PRIMARY KEY (`lseId`,`catName`,`sName`);

--
-- Indexes for table `tbl_mi`
--
ALTER TABLE `tbl_mi`
  ADD PRIMARY KEY (`miId`,`catName`,`sName`);

--
-- Indexes for table `tbl_qanda`
--
ALTER TABLE `tbl_qanda`
  ADD PRIMARY KEY (`qId`);

--
-- Indexes for table `tbl_sc`
--
ALTER TABLE `tbl_sc`
  ADD PRIMARY KEY (`scId`);

--
-- Indexes for table `tbl_serv_details`
--
ALTER TABLE `tbl_serv_details`
  ADD PRIMARY KEY (`sId`,`catName`);

--
-- Indexes for table `tbl_sht`
--
ALTER TABLE `tbl_sht`
  ADD PRIMARY KEY (`shtId`,`catName`,`sName`);

--
-- Indexes for table `tbl_transaction`
--
ALTER TABLE `tbl_transaction`
  ADD PRIMARY KEY (`phId`);

--
-- Indexes for table `tbl_wedding`
--
ALTER TABLE `tbl_wedding`
  ADD PRIMARY KEY (`wId`,`sName`,`catName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_catering`
--
ALTER TABLE `tbl_catering`
  MODIFY `cId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_client`
--
ALTER TABLE `tbl_client`
  MODIFY `cId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_fn`
--
ALTER TABLE `tbl_fn`
  MODIFY `fnId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_lse`
--
ALTER TABLE `tbl_lse`
  MODIFY `lseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_mi`
--
ALTER TABLE `tbl_mi`
  MODIFY `miId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_qanda`
--
ALTER TABLE `tbl_qanda`
  MODIFY `qId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_sc`
--
ALTER TABLE `tbl_sc`
  MODIFY `scId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_serv_details`
--
ALTER TABLE `tbl_serv_details`
  MODIFY `sId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sht`
--
ALTER TABLE `tbl_sht`
  MODIFY `shtId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_transaction`
--
ALTER TABLE `tbl_transaction`
  MODIFY `phId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tbl_wedding`
--
ALTER TABLE `tbl_wedding`
  MODIFY `wId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
