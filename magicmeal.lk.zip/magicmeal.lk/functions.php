<?php

//common functions

function fileName() {

    $today = time();
    $startDate = date('YmdHi', strtotime('2017-03-14 09:06:00'));
    $range = $startDate - $today;
    $rand = rand(0, $range);
    $imgname = $rand . "_" . ($startDate + $rand) . '_' . $today . "_wintan_lk";
    return $imgname;
}

function seoUrl($text) {
    //Lower case everything
    $string = strtolower($text);
    //Make alphanumeric (removes all other characters)
    $string2 = preg_replace("/[^a-z0-9_\s-]/", "", $string);
    //Clean up multiple dashes or whitespaces
    $string3 = preg_replace("/[\s-]+/", " ", $string2);
    //Convert whitespaces and underscore to dash
    $string4 = preg_replace("/[\s_]/", "-", $string3);
    return $string4;
}

function getAll($table, $order) {

    $query = "SELECT * FROM `$table` ORDER BY $order";

    $db = new DB();

    $result = $db->readQuery($query);
    $db->close_connection();

    $array_res = array();

    while ($row = mysqli_fetch_array($result)) {
        array_push($array_res, $row);
    }

    return $array_res;
}

function getAllForPage($table, $column, $order, $limit) {

    $page = (int) (!isset($_GET["page"]) ? 1 : $_GET["page"]);

    $startpoint = ($page * $limit) - $limit;

    $query = "SELECT * FROM `$table` ORDER BY $column $order LIMIT {$startpoint} , {$limit}";

    $db = new DB();

    $result = $db->readQuery($query);
    $db->close_connection();

    $array_res = array();

    while ($row = mysqli_fetch_array($result)) {
        array_push($array_res, $row);
    }

    return $array_res;
}

function getById($table, $id) {

    $query = "SELECT * FROM `$table` WHERE `id` = '$id' LIMIT 1";

    $db = new DB();
    $result = $db->readQuery($query);
    $db->close_connection();

    $row = mysqli_fetch_assoc($result);

    return $row;
}

function pagination($query, $per_page = 10, $page = 1, $url = '?') {

    $query = "SELECT COUNT(*) as `num` FROM {$query}";

    $db = new DB();
    $result = $db->readQuery($query);
    $db->close_connection();
    $row = mysqli_fetch_array($result);

    $total = $row['num'];
    $adjacents = "2";

    $page = ($page == 0 ? 1 : $page);
    $start = ($page - 1) * $per_page;

    $prev = $page - 1;
    $next = $page + 1;
    $lastpage = ceil($total / $per_page);
    $lpm1 = $lastpage - 1;


    $pagination = "";
    if ($lastpage > 1) {
        $pagination .= "<ul class='pagination'>";
        $pagination .= "<li class='details'>Page $page of $lastpage</li>";
        if ($lastpage < 7 + ($adjacents * 2)) {
            for ($counter = 1; $counter <= $lastpage; $counter++) {
                if ($counter == $page)
                    $pagination .= "<li><a class='current'>$counter</a></li>";
                else
                    $pagination .= "<li><a href='page-$counter.html'>$counter</a></li>";
            }
        }
        elseif ($lastpage > 5 + ($adjacents * 2)) {
            if ($page < 1 + ($adjacents * 2)) {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li><a class='current'>$counter</a></li>";
                    else
                        $pagination .= "<li><a href='page-$counter.html'>$counter</a></li>";
                }
                $pagination .= "<li class='dot'>...</li>";
                $pagination .= "<li><a href='page-$lpm1.html'>$lpm1</a></li>";
                $pagination .= "<li><a href='page-$lastpage.html'>$lastpage</a></li>";
            }
            elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                $pagination .= "<li><a href='page-1.html'>1</a></li>";
                $pagination .= "<li><a href='page-2.html'>2</a></li>";
                $pagination .= "<li class='dot'>...</li>";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li><a class='current'>$counter</a></li>";
                    else
                        $pagination .= "<li><a href='page-$counter.html'>$counter</a></li>";
                }
                $pagination .= "<li class='dot'>..</li>";
                $pagination .= "<li><a href='page-$lpm1.html'>$lpm1</a></li>";
                $pagination .= "<li><a href='page-$lastpage.html'>$lastpage</a></li>";
            }
            else {
                $pagination .= "<li><a href='page-1.html'>1</a></li>";
                $pagination .= "<li><a href='page-2.html'>2</a></li>";
                $pagination .= "<li class='dot'>..</li>";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination .= "<li><a class='current'>$counter</a></li>";
                    else
                        $pagination .= "<li><a href='page-$counter.html'>$counter</a></li>";
                }
            }
        }

        if ($page < $counter - 1) {
            $pagination .= "<li><a href='page-$next.html'>Next</a></li>";
            $pagination .= "<li><a href='page-$lastpage.html'>Last</a></li>";
        } else {
            $pagination .= "<li><a class='current'>Next</a></li>";
            $pagination .= "<li><a class='current'>Last</a></li>";
        }
        $pagination .= "</ul>";
    }


    return $pagination;
}

//add functions

function addDoctor($post, $file) {
    $addImgName = fileName();
    $dictionary = '../images/doctor/';
    $tumbDictionary = '../images/doctor/thumb/';
    $handle = new Upload($file['image']);

    if ($handle->uploaded) {
        $handle->image_resize = true;
        $handle->file_new_name_ext = 'jpg';
        $handle->image_ratio_crop = 'C';
        $handle->file_new_name_body = $addImgName;
        $handle->image_x = 350;
        $handle->image_y = 350;

        $handle->Process($dictionary);

        if ($handle->processed) {
            $info = getimagesize($handle->file_dst_pathname);
            $imgName = $handle->file_dst_name;
        }

        $handle->image_resize = true;
        $handle->file_new_name_ext = 'jpg';
        $handle->image_ratio_crop = 'C';
        $handle->file_new_name_body = $addImgName;
        $handle->image_x = 100;
        $handle->image_y = 100;

        $handle->Process($tumbDictionary);

        if ($handle->processed) {
            $info = getimagesize($handle->file_dst_pathname);
        }
    }

    $db = new DB();

    $query = "INSERT INTO `doctor` (first_name,last_name,contact_no,email,address,birthday,gender,specialization,image_name)
VALUES ('" . ($_POST['firstName']) . "', "
            . "'" . ($_POST['lastName']) . "', "
            . "'" . ($_POST['phone']) . "', "
            . "'" . ($_POST['email']) . "', "
            . "'" . ($_POST['address']) . "', "
            . "'" . ($_POST['dob']) . "', "
            . "'" . ($_POST['gender']) . "', "
            . "'" . ($_POST['specialization']) . "', "
            . "'" . ($imgName) . "')";

    $result = $db->readQuery($query);
    $db->close_connection();
    return $result;
}

function editDoctor($post, $file) {

    $dictionary = '../images/doctor/';
    $tumbDictionary = '../images/doctor/thumb/';
    $oldImg = $_POST['oldImg'];
    $handle = new Upload($file['image']);

    if ($handle->uploaded) {
        $handle->image_resize = true;
        $handle->file_new_name_body = TRUE;
        $handle->file_overwrite = TRUE;
        $handle->file_new_name_ext = FALSE;
        $handle->image_ratio_crop = 'C';
        $handle->file_new_name_body = $oldImg;
        $handle->image_x = 350;
        $handle->image_y = 350;

        $handle->Process($dictionary);

        if ($handle->processed) {
            $info = getimagesize($handle->file_dst_pathname);
            $imgName = $handle->file_dst_name;
        }


        $handle->image_resize = true;
        $handle->file_new_name_body = TRUE;
        $handle->file_overwrite = TRUE;
        $handle->file_new_name_ext = FALSE;
        $handle->image_ratio_crop = 'C';
        $handle->file_new_name_body = $oldImg;
        $handle->image_x = 100;
        $handle->image_y = 100;

        $handle->Process($tumbDictionary);

        if ($handle->processed) {
            $info = getimagesize($handle->file_dst_pathname);
            $imgName = $handle->file_dst_name;
        }
    }
  
    $db = new DB();

    $sql = "UPDATE `doctor` SET "
            . "`first_name` = '" . $_POST['firstName'] . "',"
            . "`last_name` = '" . $_POST['lastName'] . "',"
            . "`contact_no` = '" . $_POST['phone'] . "',"
            . "`email` = '" . $_POST['email'] . "',"
            . "`address` = '" . $_POST['address'] . "',"
            . "`birthday` = '" . $_POST['dob'] . "',"
            . "`gender` = '" . $_POST['gender'] . "',"
            . "`specialization` = '" . $_POST['specialization'] . "'"
            . "WHERE `id` = '" . $_POST['id'] . "'";

    $db = new DB();

    $result = $db->readQuery($sql);

    $db->close_connection();
    return $result;
}

function uploadProfile($post, $file) { 
     
    $dictionary = 'img/profile/';
    $tumbDictionary = 'img/profile/thumb/';
    
    $oldImg = $_POST['oldImg']; 
    $handle = new Upload($_FILES['image']);

    if ($handle->uploaded) {
        $handle->image_resize = true;
        $handle->file_new_name_body = TRUE;
        $handle->file_overwrite = TRUE;
        $handle->file_new_name_ext = FALSE;
        $handle->image_ratio_crop = 'C';
        $handle->file_new_name_body = $oldImg;
        $handle->image_x = 350;
        $handle->image_y = 350;

        $handle->Process($dictionary);

        if ($handle->processed) {
            $info = getimagesize($handle->file_dst_pathname);
            $imgName = $handle->file_dst_name;
        }


        $handle->image_resize = true;
        $handle->file_new_name_body = TRUE;
        $handle->file_overwrite = TRUE;
        $handle->file_new_name_ext = FALSE;
        $handle->image_ratio_crop = 'C';
        $handle->file_new_name_body = $oldImg;
        $handle->image_x = 100;
        $handle->image_y = 100;

        $handle->Process($tumbDictionary);

        if ($handle->processed) {
            $info = getimagesize($handle->file_dst_pathname);
            $imgName = $handle->file_dst_name;
        }
    }

     $db = new DB();

    $sql = "UPDATE `patient` SET "
            . "`image_name` = '" . $imgName . "'"
            . "WHERE `contact_no` = '" . $_POST['phone'] . "'";

    $db = new DB();

    $result = $db->readQuery($sql);

    $db->close_connection();
    return $result;
}


function addPatient($post) {
 
    $db = new DB();

    $query = "INSERT INTO `patient` (first_name,last_name,contact_no,address,birthday,gender,password)
VALUES ('" . ($_POST['firstName']) . "', "
            . "'" . ($_POST['lastName']) . "', "
            . "'" . ($_POST['phone']) . "', " 
            . "'" . ($_POST['address']) . "', "
            . "'" . ($_POST['dob']) . "', "
            . "'" . ($_POST['gender']) . "', "
            . "'" . ($_POST['phone']) . "')";

    $result = $db->readQuery($query);
    $db->close_connection();
    return $result;
}

function signUp($post) {
 
    $db = new DB();

    $query = "INSERT INTO `patient` (first_name,last_name,contact_no,address,birthday,gender,password)
VALUES ('" . ($_POST['firstName']) . "', "
            . "'" . ($_POST['lastName']) . "', "
            . "'" . ($_POST['phone']) . "', " 
            . "'" . ($_POST['address']) . "', "
            . "'" . ($_POST['dob']) . "', "
            . "'" . ($_POST['gender']) . "', "
            . "'" . ($_POST['pass']) . "')";

    $result = $db->readQuery($query);
    $db->close_connection();
    return $result;
}

function editPatient($post,$id) {
  
    $db = new DB();

    $sql = "UPDATE `patient` SET "
            . "`first_name` = '" . $_POST['firstName'] . "',"
            . "`last_name` = '" . $_POST['lastName'] . "',"
            . "`contact_no` = '" . $_POST['phone'] . "',"
            . "`address` = '" . $_POST['address'] . "',"
            . "`birthday` = '" . $_POST['dob'] . "',"
            . "`gender` = '" . $_POST['gender'] . "'"
            . "WHERE `id` = '" . $id . "'";

    $db = new DB();

    $result = $db->readQuery($sql);

    $db->close_connection();
    return $result;
}

function addAppointment($post) {
 
    $db = new DB();

    $query = "INSERT INTO `appointment` (patient_id,doctor_id,first_name,last_name,gender,age,contact_no,date,time,message)
VALUES ('" . ($_POST['patient']) . "', "
            . "'" . ($_POST['doctor']) . "', "
            . "'" . ($_POST['firstName']) . "', " 
            . "'" . ($_POST['lastName']) . "', "
            . "'" . ($_POST['gender']) . "', "
            . "'" . ($_POST['age']) . "', "
            . "'" . ($_POST['phone']) . "', " 
            . "'" . ($_POST['date']) . "', "
            . "'" . ($_POST['time']) . "', " 
            . "'" . ($_POST['message']) . "')";

    $result = $db->readQuery($query);
    $db->close_connection();
    return $result;
}

function addPayment($post) {
    
    $date = date("Y-m-d");


    $db = new DB();

    $query = "INSERT INTO `payment` (appointmnet_id,lab_charge,nursing_charge,room_charge,medicine_charge,doctor_charge,date)
VALUES ('" . ($_POST['appointmentId']) . "', "
            . "'" . ($_POST['labCharge']) . "', "
            . "'" . ($_POST['nursingCharge']) . "', " 
            . "'" . ($_POST['roomCharge']) . "', "
            . "'" . ($_POST['medicineCharge']) . "', "
            . "'" . ($_POST['doctorCharge']) . "', "  
            . "'" . ($date) . "')";

    $result = $db->readQuery($query);
    $db->close_connection();
    return $result;
}
function editAppointment($post,$id) {
  
    $db = new DB();

    $sql = "UPDATE `appointment` SET "
            . "`patient_id` = '" . $_POST['pid'] . "',"
            . "`doctor_id` = '" . $_POST['did'] . "',"
            . "`first_name` = '" . $_POST['firstName'] . "',"
            . "`last_name` = '" . $_POST['lastName'] . "',"
            . "`gender` = '" . $_POST['gender'] . "',"
            . "`age` = '" . $_POST['age'] . "',"
            . "`contact_no` = '" . $_POST['cnum'] . "',"
            . "`date` = '" . $_POST['date'] . "',"
            . "`time` = '" . $_POST['time'] . "',"
            . "`message` = '" . $_POST['message'] . "'"
            . "WHERE `id` = '" . $id . "'";

    $db = new DB();

    $result = $db->readQuery($sql);

    $db->close_connection();
    return $result;
}

function updateApp($post) {
    $id = $_POST['appointmentId'];
  $status = 1;
    $db = new DB();

    $sql = "UPDATE `appointment` SET "
            . "`status` = '" . $status . "'"
            . "WHERE `id` = '" . $id . "'";

    $db = new DB();

    $result = $db->readQuery($sql);

    $db->close_connection();
    return $result;
}

function updatePatient($post,$mobile) { 

    $sql = "UPDATE `patient` SET "
            . "`first_name` = '" . $_POST['firstName'] . "',"
            . "`last_name` = '" . $_POST['lastName'] . "',"
            . "`contact_no` = '" . $_POST['phone'] . "',"
            . "`address` = '" . $_POST['address'] . "',"
            . "`birthday` = '" . $_POST['dob'] . "',"
            . "`gender` = '" . $_POST['gender'] . "'"
            . "WHERE `contact_no` = '" . $mobile . "'";

    $db = new DB();

    $result = $db->readQuery($sql);

    $db->close_connection();
    return $result;
}