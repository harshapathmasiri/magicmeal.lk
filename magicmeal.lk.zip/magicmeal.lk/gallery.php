<?php session_start() ?>

<?php
$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/style_index.css" />
        <link rel="stylesheet" type="text/css" href="css/" />

        <script src="js/script.js"></script>

        <title>Gallery | Magic Meal</title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body>
        <?php
        include_once("includes/navbar.php");
        ?>

        <div class="content1">
            <table align="center" border="0" class="tblServCards">
                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/1.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/1.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/2.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/2.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/3.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/3.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/4.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/4.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/5.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/5.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/6.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/6.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/7.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/7.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/8.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/8.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/9.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/9.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/10.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/10.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/11.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/11.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/12.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/12.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/13.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/13.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/14.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/14.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/15.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/15.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/16.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/16.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/17.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/17.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/18.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/18.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/19.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/19.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/20.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/20.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/21.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/21.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>
            </table>
        </div>

        <?php
        include_once("includes/footer.php");
        ?>
        <script type="text/javascript">

        </script>

        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDz_qDNvKnEONeyMDwl0jRB8R39YkYDyiQ &callback=initMap" type="text/javascript"></script>


    </body>

</html>
