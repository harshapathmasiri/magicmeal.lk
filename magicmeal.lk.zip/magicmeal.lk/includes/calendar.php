<div class="calendar">
    <div class="month">      
      <ul>
        <li class="prev" id="btnPrev">&#10094;</li>
        <li class="next" id="btnNext">&#10095;</li>
        <li id="calendarYear">Year</li>
        <li id="calendarMonth">Month</li>
      </ul>
    </div>
    
    <ul class="weekdays">
        <table class="tblWeekdays" align="center" border="0">
            <tr>
                <td>
                  <li>Su</li>
                </td>
                
                <td>
                  <li>Mo</li>
                </td>
                
                <td>
                  <li>Tu</li>
                </td>
                
                <td>
                  <li>We</li>
                </td>
                
                <td>
                  <li>Th</li>
                </td>
                
                <td>
                  <li>Fr</li>
                </td>
                
                <td>
                  <li>Sa</li>
                </td>
                
            </tr>
        </table>
    </ul>
    
    <ul class="days"> 
        <table class="tblDays" align="center" border="0">
            <tr>
                <td>
                  <li class="calCommonDay" id="cd1" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd2" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd3" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd4" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd5" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd6" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd7" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
            </tr>
            
            <tr>
                <td>
                  <li class="calCommonDay" id="cd8" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd9" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd10" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd11" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd12" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd13" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd14" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
            </tr>

            <tr>
                <td>
                  <li class="calCommonDay" id="cd15" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd16" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd17" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd18" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd19" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd20" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd21" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
            </tr>

            <tr>                
                <td>
                  <li class="calCommonDay" id="cd22" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd23" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd24" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd25" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd26" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd27" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd28" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
            </tr>


            <tr>                
                <td>
                  <li class="calCommonDay" id="cd29" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd30" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd31" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd32" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd33" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd34" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
                
                <td>
                  <li class="calCommonDay" id="cd35" onclick="dayOnClick(this.innerHTML,this.id,this.getAttribute('class'))"></li>
                </td>
            </tr>

        </table> 
    </ul>
    <input type="button" name="btnClearCal" id="btnClearCal" value="Reset" />    	
</div>
