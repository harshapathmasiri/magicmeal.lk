<?php
include("db.php");
$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);

$name = "";
$email = "";
$question = "";
$output = "";
$done = "";

if (isset($_POST["btnFaqSub"])) {
    $name = $_POST["txtName"];
    $email = $_POST["txtEmail"];
    $question = $_POST["txtFaqTxtField"];

    $sql = "INSERT INTO tbl_qanda(question,name,email) VALUES('$question','$name','$email')";

    if ($output = mysqli_query($conn, $sql)) {
        $done = "<p class='qSubmitted'>Your question has been successfully submitted!</p>";
    } else {
        $done = "<p class='qSubmitted'>Error saving!</p>";
    }
}

mysqli_close($conn);
?>

<div id="idFooter" class="footer">

    <div class="footerSec1">
        <div class="about sec1Common">
            <p class="pAboutTitle">About us</p>
            <p class="pAboutContent fc" align="left">Magic Meal Online Food Ordering Service.</p>
            <p class="pSubsTitle">Subscribe us</p>
            <div class="subscribe">
                <form method="post" action="">
                    <input type="text" id="txtSubscribe" name="txtSubscribe" placeholder="Enter your email" />
                    <input type="submit" id="btnSubscribe" name="btnSubscribe" value="Subscribe me!" />
                </form>
            </div>
        </div>

        <div class="faq sec1Common">
            <p class="pFaqTitle" align="center">FAQ</p>
            <p class="pFaqContent fc" align="center">Frequently asked questions</p>
            <div class="faQuestions" align="center">
                <?php
                $conn1 = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);
                $sql1 = "SELECT question from tbl_qanda ORDER BY RAND() LIMIT 4";

                if ($output1 = mysqli_query($conn1, $sql1)) {
                    if ($output1->num_rows > 0) {
                        while ($row1 = $output1->fetch_assoc()) {
                            echo('
									<a href="#">' . $row1['question'] . '</a>
								');
                        }
                    }
                }
                ?>
            </div>
            <div class="faqForm">
                <p class="pFaqContent1 fc" align="center">Ask a question</p>
                <form method="post" action="">
                    <input type="text" name="txtName" placeholder="Enter your name"><br>
                    <input type="text" name="txtEmail" placeholder="Enter your email"><br>
                    <textarea placeholder="Type your question here" name="txtFaqTxtField"></textarea><br />
                    <input type="submit" id="btnFaqSub" name="btnFaqSub" value="Submit"/>
                </form>

            </div>
        </div> 

        <div class="contact sec1Common">
            <p class="pContactTitle">Contact us</p>
            <p class="pContactContent fc">+94 77 241 7000<br />No:141, 5th Lane, Kollupitiya, Colombo 03<br />harshapathmasiri@gmail.com</p>
            <p class="pContactTitle1">Find us on</p>
            <div class="contactIcons">
                <a href="https://www.facebook.com/SandysBnR"><i><img src="images/icons/facebook.png" width="30px" /></i></a>                  
                <a href="#"><i><img src="images/icons/twitter.png" width="30px"/></i></a>                  
                <a href="#"><i><img src="images/icons/linkedin.png" width="30px"/></i></a>                  
                <a href=""><i><img src="images/icons/gmail.png" width="30px"/></i></a>                  
            </div>
        </div>
    </div>

    <hr class="hrFooter" />

    <div class="privacy">
        <small class="smallPrivacy">magicmeal.lk | All Rights Reserved 2021 | <a href="#">cookies</a> | <a href="#">privacy</a> | <a href="#">advertise here</a> | <a href="#">terms & conditions</a></small>
    </div>

</div>
