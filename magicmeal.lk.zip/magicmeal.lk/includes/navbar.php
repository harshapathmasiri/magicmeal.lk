<div class="nav" id="idNav">
    <ul>
        <table align="center" border="0" width="70%" class="tblNav">
            <tr>
                <td>
            <li class="left" style="margin-left: -160px; margin-top: -53px; margin-bottom: -3px"><a href="./index.php"><img src="./images/logo/logo.jpg" style="height: 140px; width: 140px; margin-right: 50px"/></a></li>
            <li class="left"><a href="./index.php" class="links main">Home</a></li>
            <li class="left"><a href="./servWeddings.php" id="btnServices" class="links main">Our Menu</a></li>
            <li class="left"><a href="./gallery.php" id="btnServices" class="links main">Gallery</a></li>
            <li class="left"><a href="./aboutUs.php" id="btnServices" class="links main">About Us</a></li>
            <li class="left"><a href="./contactUs.php" id="btnServices" class="links main">Contact Us</a></li>
            <li class="cart"><a href="./cart.php" class="aCart" id="idCart"><img name="imgCart" src="images/icons/cart1_black.png" height="19px"></a></li>
            <li class="right user" <?php if ($loggedStatus == 1) {
    echo('style="display:block;"');
} else {
    echo('style="display:none;"');
} ?>><a href="#" class="links main aUser"><?php
                    $sess_row = "";
                    if (isset($_SESSION["clientRow"]) && isset($_SESSION["clientLogin"])) {
                        $sess_row = $_SESSION["clientRow"];
                        echo($sess_row["username"]);
                    } else {
                        echo("");
                    }
                    ?></a>         
                <div class="dropDwnCont">
                    <a <?php if ($loggedStatus == 1) {
                        echo('style="display:block;"');
                    } else {
                        echo('style="display:none;"');
                    } ?> href="./profile.php" class="aProf">My Profile</a>
                    <a <?php if ($loggedStatus == 1) {
                        echo('style="display:block;"');
                    } else {
                        echo('style="display:none;"');
                    } ?> href="./purchaseHistory.php" class="aPHis">Purchase History</a>
                    <a <?php if ($loggedStatus == 1) {
                        echo('style="display:block;"');
                    } else {
                        echo('style="display:none;"');
                    } ?> href="logout.php" class="alogout">Logout</a>
                </div>           
            </li>
            <li class="right"><a href="./register.php" class="links main">Register</a></li>
            <li class="right" <?php if ($loggedStatus == 0) {
                        echo('style="display:block;"');
                    } else {
                        echo('style="display:none;"');
                        } ?>><a href="./login.php" class="links main">Login</a></li>
            </td>
            </tr>
        </table>
    </ul>
</div>

<script type="text/javascript">

    document.getElementById("idCart").onmouseover = function cartMouseOver() {
        document.imgCart.src = "images/icons/cart1.png";
    }

    document.getElementById("idCart").onmouseout = function cartMouseOut() {
        document.imgCart.src = "images/icons/cart1_black.png";
    }

</script>