// JavaScript Document

/*Home page Scroll on click*/
	function downArrowMouseOver(){
		document.imgDownArrow.src="images/icons/downarrow2_yellow.png";
	}

	function downArrowMouseOut(){
		document.imgDownArrow.src="images/icons/downarrow2.png";
	}

	function scrollToAbout(){
		window.scroll({ top: 700, left: 0, behavior: 'smooth' });		
	}


/*Google Maps*/
function initMap(){
	var myLatlng = new google.maps.LatLng(6.9270786,79.861243);
	var mapOptions = {
	  zoom: 14,
	  center: myLatlng
	}
	var map = new google.maps.Map(document.getElementById("idMap"), mapOptions);

	var marker = new google.maps.Marker({
		position: myLatlng,
		title:"Hello World!"
	});
	marker.setMap(map);
}

/*Slider*/
	var slideIndex = 0;

	var url = window.location.href;
	if(url.includes("servWeddings")){
		slideIndex += 0;
	}else{
		if(url.includes("servCatering")){
			slideIndex += 1;
		}else{
			if(url.includes("servFuncNeeds")){
				slideIndex += 2;
			}else{
				if(url.includes("servLightSE")){
					slideIndex += 3;
				}else{
					if(url.includes("servStageHT")){
						slideIndex += 4;
					}else{
						if(url.includes("servMusicIB")){
							slideIndex += 5;
						}else{
							slideIndex += 0;
						}					
					}					
				}
			}
		}
	}

function showSlides() {
	var i;
	var slides = document.getElementsByClassName("slides");
	for (i = 0; i < slides.length; i++) {
	   slides[i].style.display = "none";  
	}
	slideIndex++;
	if (slideIndex > slides.length) {slideIndex = 1}    
	slides[slideIndex-1].style.display = "block";  
	setTimeout(showSlides, 4000);
}




/*Calendar*/
function calendar(){
	var date = new Date();
	var monthArray = ["January","February","March","April","May","June","July","August","September","October","November","December"];
	var month = parseInt(date.getMonth());
	var year = parseInt(date.getFullYear());
	var btnNClkIn = 6;
	var btnPClkIn = 0;
	
	
	document.getElementById('btnClearCal').value = date.getFullYear()+" / "+monthArray[date.getMonth()]+" / "+date.getDate();
	clearCal();
	setCal(month,year);
	findToday();
		
	document.getElementById('btnNext').onclick = (function(){
		
		if(btnNClkIn>0 && btnNClkIn<=6 && btnPClkIn<6 && btnPClkIn>=0){
			btnNClkIn--;
			btnPClkIn++;
			month++;
			if(month>11){
				year++;
				month=0;	
			}
			clearCal();		
			setCal(month,year);
			findToday();
		}else{
			var txtSelDate = document.getElementById('txtSelDate');
			txtSelDate.value = "Sorry! Booking can be done only 6 months ahead";
			txtSelDate.style.border = "solid 1px red";
		}
	});
		
	document.getElementById('btnPrev').onclick = (function(){
		
		
		if(btnNClkIn>=0 && btnNClkIn<6 && btnPClkIn<=6 && btnPClkIn>0){
			btnNClkIn++;
			btnPClkIn--;
			month--;
			if(month<0){
				year--;
				month=11;	
			}
			clearCal();		
			setCal(month,year);
			findToday();
		}
	});
		
	document.getElementById('btnClearCal').onclick = (function(){
		month = parseInt(date.getMonth());
		year = parseInt(date.getFullYear());	
		
		clearCal();		
		setCal(month,year);
		findToday();
		btnNClkIn = 6;
		btnPClkIn = 0;
	});
	
	
	
		function setCal(month,year){
			
			var msec = Date.parse(monthArray[month]+" 1, "+year);
			var referenceDay = new Date(msec);
			
			var todayDate = referenceDay.getDay();
				
			document.getElementById('calendarYear').innerHTML = year;
			document.getElementById('calendarMonth').innerHTML = monthArray[month];
			
			var days = document.getElementsByClassName('calCommonDay');
			
			var thirtyfirst = [0,2,4,6,7,9,11];
			var maxDay = 0;
			
			for(var i=0; i<thirtyfirst.length;i++){
				if(referenceDay.getMonth() == thirtyfirst[i]){
					maxDay = 31;
					break;
				}
			}
			
			if(referenceDay.getMonth() != thirtyfirst && referenceDay.getMonth() != 1 && maxDay!=31){
				maxDay = 30;
			}else{
				if(referenceDay.getMonth() == 1 && maxDay!=30){
					if(year%4==0 && (year%100!=0 || year%400==0)){
						maxDay = 29;
					}else{
						maxDay = 28;
					}
				}	
			}
					
			for(var i=todayDate; i<days.length; i++){
				if((i-(todayDate-1))>maxDay){
					break;
				}
				document.getElementById('cd'+(i+1)).innerHTML = i-(todayDate-1);
			}
				
			var lastPossitionValue = document.getElementById('cd35').innerHTML;
			if(!(isNaN(lastPossitionValue))){
				var lastPossitionValueINT = parseInt(lastPossitionValue);
			}
					
			
			if(todayDate>4 && !(isNaN(lastPossitionValueINT))){
				for(var i=0; i<todayDate; i++){
					if((lastPossitionValueINT+1)>maxDay){
						break;	
					}
					document.getElementById('cd'+(i+1)).innerHTML = lastPossitionValueINT+1;
					lastPossitionValueINT++;
				}		
			}
		}
		
		
		
		
		function clearCal(){
			for(var i=0; i<35; i++){
				document.getElementById('cd'+(i+1)).innerHTML = '';
			}
		}
		
		
		function findToday(){
			clearActiveClass();
			var today = [date.getFullYear(),monthArray[date.getMonth()],date.getDate()];
			var todayDateId = 0;
			
			var yearOnCal = document.getElementById('calendarYear').innerHTML;
			var monthOnCal = document.getElementById('calendarMonth').innerHTML;
			
			if(yearOnCal==today[0] && (monthOnCal.toString()).toUpperCase()==(today[1].toString()).toUpperCase()){
				
				for(var i=0; i<35; i++){
					if(today[2] == (document.getElementById('cd'+(i+1)).innerHTML)){
						todayDateId = i+1;
						break;		
					}
				}
				
				document.getElementById('cd'+todayDateId).classList.add("active");				
			}
			
			
			
			/*Restrict ordered dates*/
			var txtOrderedDateClasses = document.getElementsByClassName("txtClsOrderedDates");
			
			for(var i=0; i<txtOrderedDateClasses.length; i++){
				var A = (txtOrderedDateClasses[i].value).split("-");
				restrictOrderedDates(A[0].trim()/1, A[1].trim()/1, A[2].trim()/1);
			}

		}
		
		function clearActiveClass(){
			var txtSelDate = document.getElementById('txtSelDate');

			for(var i=0; i<35; i++){
				document.getElementById('cd'+(i+1)).classList.remove("active");
				document.getElementById('cd'+(i+1)).classList.remove("clicked");
				document.getElementById('cd'+(i+1)).classList.remove("restrict");
			}
			
			txtSelDate.value = null;
			txtSelDate.style.border = "solid 1px #222";
		}
	
		function restrictOrderedDates(year,month,date){
			var yearOnCal = document.getElementById('calendarYear').innerHTML;
			var monthOnCal = document.getElementById('calendarMonth').innerHTML;
			var todayDateId = 0;
			
			if(year == yearOnCal && (monthOnCal.toString()).toUpperCase()==(monthArray[month-1]).toUpperCase()){
				
			for(var i=0; i<35; i++){
				if(date == (document.getElementById('cd'+(i+1)).innerHTML)){
					todayDateId = i+1;
					break;		
				}
			}
				
			    document.getElementById('cd'+todayDateId).classList.add("restrict");
			}
			
		}
					
	
}

function dayOnClick(innerHTML,clickedId,clickedClasses){
	var date = new Date();
	var monthArray = ["January","February","March","April","May","June","July","August","September","October","November","December"];
	var txtSelDate = document.getElementById('txtSelDate');	
	var innerHTML_INT = parseInt(innerHTML);
	var yearOnCal = document.getElementById('calendarYear').innerHTML;
	var monthOnCal = document.getElementById('calendarMonth').innerHTML;
	var restrictStatus = false;
	
	
	var C = clickedClasses.split(" ");
	for(var i=0; i<C.length; i++){
		if(C[i] == "restrict"){
			restrictStatus = true;
		    break;
		}
	}
	
	if(!isNaN(innerHTML_INT)){
		if(!restrictStatus){
			if(((monthOnCal.toString()).toUpperCase()==monthArray[date.getMonth()].toUpperCase()) && (yearOnCal==date.getFullYear())){
				if(innerHTML_INT>=parseInt(date.getDate())){
					setDateClicked();
				}else{
					setDateError();
				}
			}else{
				setDateClicked();
			}
		}else{
			restrictError();
		}
	}
	
	
	function setDateClicked(){
		txtSelDate.value = yearOnCal+" / "+monthOnCal+" / "+innerHTML_INT;
		txtSelDate.style.border = "solid 1px green";
		clearClicked();	
		document.getElementById(clickedId).classList.add("clicked");
	}
	
	function setDateError(){
		clearClicked();	
		txtSelDate.value = "Invalied Selection!";
		txtSelDate.style.border = "solid 1px red";
	}
	
	function restrictError(){
		clearClicked();	
		txtSelDate.value = "Sorry the item has been booked on that day!";
		txtSelDate.style.border = "solid 1px red";
	}
	
	function clearClicked(){
		for(var i=0; i<35; i++){
			document.getElementById('cd'+(i+1)).classList.remove("clicked");
		}	
	}
	
}







/*Form Validation*/

function valIsEmpty(id){
	var elem = document.getElementById(id);
	if(elem.value==null || elem.value==""){
		return false;
	}
	return true;
}


function valIsNumber(id){
	var elem = document.getElementById(id);
	if(isNaN(elem.value)){
	   return false;
	}
	return true;
}

function valMinimumLength(id){
	var elem = document.getElementById(id);
	if(((elem.value).length<6)){
		return false;
	}
	return true;	
}


function valEmail(id){
		var elem = document.getElementById(id);
		var at = elem.indexOf("@");
		var dt = elem.lastIndexOf(".");
		var len = elem.length;
		
		if((at < 2) || (dt-at < 2) || (len-dt < 2)){
			alert("Please enter a valid email address");
			return false;
		}
		return true;
}
	
	
/*Book.php*/
function orderValidate(){
	var valiedDate = document.getElementById("txtSelDate").value;
	if(valIsEmpty("txtOrderQty") && valIsNumber("txtOrderQty") && valIsEmpty("txtNOD") && valIsNumber("txtNOD") && valIsEmpty("txtSelDate") && valiedDate != "Invalied Selection"){
	}else{
		alert("Incorrect Details");
		event.preventDefault();
	}
}

/*Login.php*/
function valLogin(){
	if(valMinimumLength("txtPassword") && valIsEmpty("txtPassword") && valIsEmpty("txtUsername")){
	}else{
		alert("Incorrect Details");
		event.preventDefault();
	}	
}

/*Register.php*/
function valRegister(){	
	if(valIsEmpty("txtFName") && valIsEmpty("txtLName") && valIsEmpty("txtUsername") && valIsEmpty("txtEmail") && valIsEmpty("txtAddress") && valIsEmpty("txtPassword") && valIsEmpty("txtConfPassword") && valMinimumLength("txtRegPassword") && valMinimumLength("txtRegConfPassword") && valEmail("txtEmail")){
		//true
	}else{
		alert("Error");
		event.preventDefault();	
	}
}










/*Shopping Cart Mouse fn*/

function btnDeleteMOV(id){
	document.getElementById(id).src="images/icons/bin2.png";
}

function btnDeleteMOU(id){
	document.getElementById(id).src="images/icons/bin1.png";
}


/*Booking page setting price according to the type*/
function priceAccordingToType(){
	var idTxtCatName = document.getElementById('txtCatName').value;
	if(idTxtCatName == 'Stages/Huts/Tents'){
		var idCombotype = document.getElementById('comboType').value;
		var A = idCombotype.split("*");
		var prod = 1;
		for(var i=0; i<A.length; i++){
			prod *= A[i];
		}
		if(idCombotype != 'Select'){
			document.getElementById('txtTempPrice1').value = prod*(document.getElementById('txtTempPrice').value);
			document.getElementById('txtOrderDeposite').value = numberWithCommas(document.getElementById('txtTempPrice1').value);
			document.getElementById('comboType').style = "border-color: #222;";
			document.getElementById('txtOrderDeposite').style = "border-color: #222;";
		}else{
			document.getElementById('txtOrderDeposite').value = "Please select a type";
		}
	}
	priceAccordingToQty();
}

/*Booking page setting price according to the qty*/
function priceAccordingToQty(){
	var unPrice = document.getElementById("txtTempPrice");
	var unPrice1 = document.getElementById("txtTempPrice1");
	var qty = document.getElementById("txtOrderQty");
	var txtPrice = document.getElementById("txtOrderDeposite");
	var idTxtCatName = document.getElementById('txtCatName');	
	
	if(qty.value > 0 ){
		qty.style = "border-color: #222;";
		if(txtPrice.value == "Please select a type"){
			qty.value = 1;
			document.getElementById('comboType').style = "border-color: red;";
			document.getElementById('txtOrderDeposite').style = "border-color: red;";
		}else{
			if(idTxtCatName.value == 'Stages/Huts/Tents'){
				var idCombotype = document.getElementById('comboType').value;
				var A = idCombotype.split("*");
				var prod = 1;
				for(var i=0; i<A.length; i++){
					prod *= A[i];
				}
				
				unPrice1.value = unPrice.value*qty.value*prod;
				txtPrice.value = numberWithCommas(unPrice1.value);
			}else{
				document.getElementById('comboType').style = "border-color: #222;";
				document.getElementById('txtOrderDeposite').style = "border-color: 222;";
				unPrice1.value = unPrice.value*qty.value;
				txtPrice.value = numberWithCommas(unPrice1.value);
			}
		}
	}else{
		qty.value = 1;
		qty.style = "border-color: red;";
	}		
}


//Cart Page
function priceAccordingToQtyCart(id){
	var clickedIdIndex = id.substring(11,id.length);
	var qtyMultiplied = 1;
	var A = [""];
	var txtTypeCart = "";
	
	var paraServiceNameC = document.getElementById("paraServiceNameC"+clickedIdIndex);
	var txtOrderQty = document.getElementById("txtOrderQty"+clickedIdIndex);
	if((paraServiceNameC.innerHTML).substring(0,17)=="Stages/Huts/Tents"){
		txtTypeCart = document.getElementById("txtTypeCart"+clickedIdIndex);
		A = (txtTypeCart.innerHTML).split("*");
		for(var i=0; i<A.length; i++){
			qtyMultiplied*=A[i];
		}
	}
	var pricePara = document.getElementById("pricePara"+clickedIdIndex);
	
	var txtTempPrice = document.getElementById("txtTempPrice"+clickedIdIndex);
	var txtTempPricePerUnit = document.getElementById("txtTempPricePerUnit"+clickedIdIndex);
	
	txtTempPrice.value = txtOrderQty.value*qtyMultiplied*txtTempPricePerUnit.value;
	pricePara.innerHTML = numberWithCommas(parseInt(txtOrderQty.value*qtyMultiplied*txtTempPricePerUnit.value));
	
	cartOnLoad();
	var btnSCartDNow = 	document.getElementById("btnSCartDNow");
	
	document.getElementById("idUpdateNotice").style = "display:block";
	btnSCartDNow.disabled = true;
	btnSCartDNow.style = "background-color:#666; cursor: not-allowed;";
	document.getElementById("btnSCartUpdate").click();
}

function cartOnLoad(){
	var sum = 0;
	var pricePara = "";
	var txtTempPrice = "";
	itemCount = document.getElementById("itemCount").value;
	for(var i=0; i<itemCount; i++){
		pricePara = document.getElementById("pricePara"+i);
		txtTempPrice = document.getElementById("txtTempPrice"+i);
		sum+=parseInt(txtTempPrice.value);
		pricePara.innerHTML = numberWithCommas(txtTempPrice.value);
	}
	document.getElementById("cartTotal").innerHTML = numberWithCommas(sum);
}

function cartClearItemClicked(i){
	document.getElementById("btnClearItem"+i).click();
}



//Purchase history page
function pHisOnLoad(){
	var pHPrice = document.getElementsByClassName("pHPrice");
	
	for(var i=0; i<pHPrice.length; i++){
		pHPrice[i].innerHTML = ": LKR "+numberWithCommas(parseInt(pHPrice[i].innerHTML));
	}
}




/*Formatting numbers with commas for thousands*/
function numberWithCommas(x) {
	x = x.toString();
	var pattern = /(-?\d+)(\d{3})/;
	while (pattern.test(x))
		x = x.replace(pattern, "$1,$2");
	return x;
}		



















