<?php session_start(); ?>
<?php
include("includes/db.php");

$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);

$username = "";
$uPError = "";
$output = "";

if (isset($_POST["btnLogin"])) {

    $username = $_POST["txtUsername"];

    $sql = "SELECT * FROM tbl_client WHERE username = '$username' AND password = '" . md5("websters" . md5($_POST["txtPassword"])) . "'";
    $output = mysqli_query($conn, $sql);

    if ($output->num_rows > 0) {

        $_SESSION['clientLogin'] = true; // login state


        $row = $output->fetch_assoc();
        $_SESSION['clientRow'] = $row; //to retrieve client's info

        header("location:index.php");
    } else {
        $uPError = "Invalied username or password!";
        echo($uPError);
    }
}


$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/style_login.css" />

        <script src="js/script.js" type="text/javascript"></script>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Login | Magic Meal</title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body>

<?php
include_once("includes/navbar.php");
?>

        <div class="container">
            <form action="" method="post" class="formLogin">
                <h1 class="loginTitle">Login</h1>
                <table border="0" align="center" class="tblLoginForm">
                    <tr>
                        <td><label for="txtUsername">Username: </label></td>
                        <td><input type="text" id="txtUsername" name="txtUsername" class="inputs" placeholder="Type here..." /></td>
                    </tr>

                    <tr>
                        <td><label for="txtPassword">Password: </label></td>
                        <td><input type="password" id="txtPassword" name="txtPassword" class="inputs" /></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><input style="float: right" type="submit" name="btnLogin" id="btnLogin" value="Login" onclick="valLogin()"/></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="padding-bottom: 20px"><a href="register.php" style="color: #222"><small>Don't have an account? Register</small></a></td>
                    </tr>

                    <tr>
                        <td colspan="2">
                            <small style="color: #777">*By loging in to magicmeal.lk, you are agreeing to our site's <a href="#" style="color: #999"> Terms and conditions</a> and our <a href="#" style="color: #999"> Privacy policy. </a></small>
                        </td>
                    </tr>
                </table>
            </form>
        </div>


<?php
include_once("includes/footer.php");
?>

    </body>
</html>