<?php 	echo "My first php file"; 
		echo "<br>";
		echo "Second Line";
		echo "<br>";
		echo "First Line"." Second Line";
		// This is comment time one 
		/* COmment type 2*/
		# Single line comment
?>
