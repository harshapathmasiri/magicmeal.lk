<?php
	//Variables
	$variable_name = "Value";
	
	$firstName = "Saman";
	echo $firstName;
	echo "<br>";
	
	$age = 30;
	echo $age;
	echo "<br>";
	
?>