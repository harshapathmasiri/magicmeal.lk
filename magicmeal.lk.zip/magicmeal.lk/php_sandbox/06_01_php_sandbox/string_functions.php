<html>
	<head>
		<title>String Functions</title>
	</head>
	<body>

		<?php
			$firstString = "The quick brown fox";
			$secondString = " jumped over the lazy dog.";
		?>
		<?php
			// Concatentation
			$thirdString = $firstString;
			$thirdString .= $secondString;
			echo $thirdString;
		?>
		<br />
		Lowercase: <?php echo strtolower($thirdString); ?><br />
		Uppercase: <?php echo strtoupper($thirdString); ?><br />
		Uppercase first-letter: <?php echo ucfirst($thirdString); ?><br />
		Uppercase words: <?php echo ucwords($thirdString); ?><br />
		<br />
		Length: <?php echo strlen($thirdString); ?><br />
		Trim: <?php echo $fourthString = $firstString . trim($secondString); ?><br />
		Find: <?php echo strstr($thirdString, "brown"); ?><br />
		Replace by string: <?php echo str_replace("quick", "super-fast", $thirdString); ?><br />

		
		
		
		<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>Form Sent</title>

</head>



<body>

<?php

$name = $_POST['name'];

$company = $_POST['company'];

$city = $_POST['city'];

$phone = $_POST['phone'];

$email = $_POST['email'];

$typeofevent = $_POST['typeofevent'];

$date = $_POST['date'];

$range = $_POST['range'];

$guestsnum = $_POST['guestsnum'];

$location = $_POST['location'];

$appetizers = $_POST['appetizers'];

$bar = $_POST['bar'];

$allergies = $_POST['allergies'];

$message = $_POST['message'];

$comments = $_POST['comments'];





$email_from = "www.culinaryfightnight.com";

$email_subject = "New Contact Form submission";

$email_body = "User: $name \n"."Company/Organization : $company \n"."City: $city \n"."Phone : $phone \n"."Email: $email \n"

."Type of Event: $typeofevent \n"."Date: $date \n"."Range: $range"."Number of Guests : $guestsnum \n"."Do you have a location or shall we source one in your area? : $location \n"."Are you interested in passed appetizers during the cocktail hour prior to the competition? : $appetizers \n"."Will your group require a bar? If so, hosted or cash bar?: $bar \n".

"Are there any food allergies or special instructions we should follow when building a menu?: $allergies \n"

."Message: $message \n"."Comments :$comments";



$to = "hello@culinaryfightnight.com";

$headers = "From: $name \r\n";

$headers .= "Reply-To: $email \r\n";

mail($to,$email_subject,$email_body,$headers);

echo "Thank you for submiting form. We will contact you soon.\n \n";

?>

</body>

</html>
		
	</body>
</html>