<html>
	<head>
		<title>Variables</title>
	</head>
	<body>
	<?php /*
		start with a $, followed by letter or underscore
		can contain letters, numbers, underscores, or dashes, but no spaces
		case-sensitive
	*/ ?>

	<?php 
		$var1 = 10;
		echo $var1;
		
		// $myVariable and $myvariable are different
		$my_variable = "Hello World";
		$my_Variable = "Hello World Again";
		echo $my_Variable;
		echo "<br />";
	?>
	
	<?php
		// variables values are variable; $var1 can be assigned a new value
		$var1 = 100;
		echo $var1;
	?>
	</body>
</html>