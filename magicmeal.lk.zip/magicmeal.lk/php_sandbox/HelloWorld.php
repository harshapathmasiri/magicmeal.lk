<html>
  <head>
    <title>Hello World</title>
  </head>
  <body>
  <?php  // Single Line
    /* multi-line comment
      line 2
      line 3
    */ ?>
    <?php echo "Hello World" ; ?><br>
    <?php print "Hello World!" ; ?><br>
    <?php echo "Hello"." World!"; ?><br>
    <?php echo 2*3; ?>
  </body>
</html>
