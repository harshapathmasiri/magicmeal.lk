<html>
	<head>
		<title>String Function</title>
	</head>
	<body>
  	<?php
      $first_string = "My name is";
      $second_string = " Tharindu Weerasinghe";
    ?>
    <?php
    // Concatentation
      $third_string = $first_string;
      $third_string .= $second_string;
      echo $third_string;
    ?>

    To accept the cancellation fiverr suggest me to revert the works I have done. This is the works that I have done. I'll accept the cancellation as soon as I or your "other developer" revert my works.

    1) Content optimization :

    i) Title check
    ii) description ceck
    iii) H1-H6 check

    2)Search Optimization

    i) Canonical link check

    3)External and internal links

    i)Internal links

    4) Images

    1) image optimization

    5) concatenate css and javascript

    6) Changed optional above the fold javascript to bottom





    <br>
    Lowercase: <?php echo strtolower($third_string); ?> <br>
    Uppercase: <?php echo strtoupper($third_string); ?> <br>
    Uppercase first-letter: <?php echo ucfirst($third_string); ?><br>
    Uppercase words: <?php echo ucwords($third_string); ?>
    <br />
		Length: <?php echo strlen($third_string); ?><br />
		Trim: <?php echo $fourth_string = $first_string . trim($second_string); ?><br />
		Find: <?php echo strstr($third_string, "ind"); ?><br />
		Replace by string: <?php echo str_replace("Tharindu", "super-fast", $third_string); ?><br />

	</body>
</html>
