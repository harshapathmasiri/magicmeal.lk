<html>
	<head>
		<title>Strings</title>
	</head>
	<body>
	<?php
  // Simple string, surrounded by single quotes.
	// (included HTML still works just like HTML when output)
  echo 'This is string <br>';

  // Simple string, surrounded by double quotes. (best practice)
  echo "This is string <br>";

  // String can be assign to a variable
  $var1 = "This is String";
  echo $var1;
  echo "<br>";

  // and concatenated with other strings or variables containing strings
	echo $var1 . " Again";
  echo "<br>";
	?>
  <?php
		// PHP will substitute the value of a string for a variable inside double-quotes
    echo "$var1 Again <br>";

		// curly brackets can help make this substitution clearer
		// sometimes required to help PHP know that it is a variable
		// e.g. "{$hour}am" is clear while $houram is not
		// (best practice)
		echo "{$var1} Again <br>";

		// Variable substitution does not take place inside single quotes
		echo '$var1 Again.<br />';
	?>
	</body>
</html>
