<?php session_start() ?>

<?php
include("includes/db.php");

$loggedStatus = 0;
$sess_row = "";
$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);


//Login status
if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
        if (isset($_SESSION["clientRow"])) {
            $sess_row = $_SESSION["clientRow"];
        } else {
            header("location:index.php");
        }
    }
} else {
    $loggedStatus = 0;
    header("location:index.php");
}

$fName = "";
$lName = "";
$address = "";
$sess_cId = $sess_row['cId'];
$sess_email = $sess_row['email'];
$output = "";
$row = "";
$r_output = "";

//Retrieve records
$r_sql = "SELECT * FROM tbl_client WHERE cId = '$sess_cId' AND email = '$sess_email'";
$r_output = mysqli_query($conn, $r_sql);

if ($r_output->num_rows > 0) {
    $row = $r_output->fetch_assoc();
}



//Update the details
if (isset($_POST["btnEditDetails"])) {
    $fName = $_POST["txtProfFName"];
    $lName = $_POST["txtProfLName"];
    $address = $_POST["txtProfAddress"];

    $sql = "UPDATE tbl_client SET fName='$fName', lName='$lName', address='$address' WHERE cId='$sess_cId' AND email='$sess_email'";
    $output = mysqli_query($conn, $sql);


    if ($output) {
        header("location:profile.php");
    }
}



//Update password
$pasMatch_error = "";

$oldPass = "";
$currPass = "";
$newPass = "";
$confPass = "";
$p_sql = "";
$p_output = "";

if (isset($_POST["btnChangePassword"])) {
    $currPass = md5("websters" . md5($_POST["txtCurrentPass"]));
    $newPass = md5("websters" . md5($_POST["txtNewPass"]));
    $confPass = md5("websters" . md5($_POST["txtConfNewPass"]));

//searching for old password
    $oldPass = $row["password"];
//matching process
    if ($currPass == $oldPass) {

        if ($newPass == $confPass) {
            $p_sql = "UPDATE tbl_client SET password='$newPass' WHERE cId='$sess_cId' AND email='$sess_email'";
            $p_output = mysqli_query($conn, $p_sql);

            if ($p_output) {
                session_destroy();
                header("location:profile.php");
            }
        } else {
            $pasMatch_error = "Your password is not match!";
        }
    } else {
        $pasMatch_error = "Forget Your Old Password?";
    }
}

echo($pasMatch_error);

mysqli_close($conn);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/style_profile.css" />

        <script src="js/script.js" type="text/javascript"></script>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>My Profile</title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body>

<?php
include_once("includes/navbar.php");
?>

        <div class="container">
            <div class="profile">
                <h1 class="profileTitle">Profile Details</h1>
                <table border="0" align="center" class="tblProfile">
                    <form action="profile.php" method="post" class="formProfile">
                        <tr>
                            <td colspan="2"><p class="profileSecTitle">My Details</p></td>
                        </tr>
                        <tr>
                            <td><label for="txtProfFName">First Name:</label></td>
                            <td><input type="text" class="inputs" id="txtProfFName" name="txtProfFName" value="<?php echo($row["fName"]); ?>" /></td>
                        </tr>

                        <tr>
                            <td><label for="txtProfLName">Last Name:</label></td>
                            <td><input type="text" class="inputs" id="txtProfLName" name="txtProfLName" value="<?php echo($row["lName"]); ?>" /></td>
                        </tr>

                        <tr>
                            <td><label for="txtProfUname">Username:</label></td>
                            <td><input type="text" class="inputs" id="txtProfUname" name="txtProfUname" value="<?php echo($row["username"]); ?>" disabled="disabled"/></td>
                        </tr>
                        <tr>
                            <td><label for="txtProfEmail">Email:</label></td>
                            <td><input type="text" class="inputs" id="txtProfEmail" name="txtProfEmail" value="<?php echo($row["email"]); ?>" disabled="disabled" /></td>
                        </tr>
                        <tr>
                            <td><label for="txtProfAddress">Address:</label></td>
                            <td><textarea style="resize: none" class="inputs" id="txtProfAddress" name="txtProfAddress"><?php echo($row["address"]); ?></textarea></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" style="float: right" id="btnEditDetails" name="btnEditDetails" value="Edit Details" /></td>
                        </tr>
                    </form>




                    <!--<form action="" method="post" class="formProfile1">
                            <tr>
                                    <td colspan="2"><p class="profileSecTitle">Payment Details</p></td>
                            </tr>
                            <tr>
                                    <td><label for="txtProfUname">Card Type:</label></td>
                                    <td>
                                            <select class="inputs">
                                                    <option selected="selected">Select</option>
                                                    <option>Visa</option>
                                                    <option>Master Card</option>
                                                    <option>Discover</option>
                                                    <option>American express</option>
                                            </select>
                                    </td>
                            </tr>
                            <tr>
                                    <td><label for="txtCN">Card Number:</label></td>
                                    <td><input type="text" class="inputs" id="txtCN" name="txtCN" /></td>
                            </tr>
                            <tr>
                                    <td><input type="text" class="inputs" id="txtExpiration" name="txtExpiration" placeholder="Expiration MM/YY" /></td>
                                    <td><input type="text" class="inputs" id="txtCSC" name="txtCSC" placeholder="CSC (3-Digits)" /></td>
                            </tr>
                            <tr>
                                    <td></td>
                                    <td><input type="submit" style="float: right" id="btnSavePayDetails" name="btnSavePayDetails" value="Save Details" /></td>
                            </tr>
                    </form>-->




                    <form action="profile.php" method="post" class="formProfile2">
                        <tr>
                            <td colspan="2"><p class="profileSecTitle">Change Password</p></td>
                        </tr>
                        <tr>
                            <td><label for="txtCurrentPass">Current Password:</label></td>
                            <td><input type="password" class="inputs" id="txtCurrentPass" name="txtCurrentPass" /></td>
                        </tr>
                        <tr>
                            <td><label for="txtNewPass">New Password:</label></td>
                            <td><input type="password" class="inputs" id="txtNewPass" name="txtNewPass" /></td>
                        </tr>
                        <tr>
                            <td><label for="txtConfNewPass">Confirm Password:</label></td>
                            <td><input type="password" class="inputs" id="txtConfNewPass" name="txtConfNewPass" /></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" style="float: right" id="btnChangePassword" name="btnChangePassword" value="Change Password" /></td>
                        </tr>
                    </form>
                </table>
            </div>
        </div>


<?php
include_once("includes/footer.php");
?>

    </body>
</html>