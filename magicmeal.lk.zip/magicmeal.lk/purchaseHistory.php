<?php session_start() ?>

<?php
include("includes/db.php");

$loggedStatus = false;

if (isset($_SESSION["clientLogin"]) && isset($_SESSION["clientRow"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = true;
        $clientRow = $_SESSION["clientRow"];
    }
} else {
    $loggedStatus = false;
    header("location:index.php");
}


$uName = $clientRow["username"];
$done = "";

$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);
$sql = "SELECT * FROM tbl_transaction WHERE username = '$uName'";
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/style_pHistory.css" />

        <script src="js/script.js" type="text/javascript"></script>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Purchase History</title>

        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>

    </head>

    <body onLoad="pHisOnLoad()">

<?php
include_once("includes/navbar.php");
?>

        <div class="container">
            <div class="pHistory">
                <form action="" method="post" class="formPHistory">
                    <h1 class="pHistoryTitle">Purchase History</h1>

<?php
$dbTable = "";
$dbIdColumn = "";
$folder = "";
$conn1 = "";
$sql1 = "";
$output1 = "";
$row1 = "";
$catName = "";
$sName = "";
$status = "";
$fDateDiff = "";
$dateDiff = "";

if ($output = mysqli_query($conn, $sql)) {
    if ($output->num_rows > 0) {
        while ($row = $output->fetch_assoc()) {
            $catName = $row["catName"];
            $sName = $row["sName"];
            $conn1 = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);

            switch ($row["catName"]) {
                case "Wedding halls";
                    $dbTable = "tbl_wedding";
                    $dbIdColumn = "wId";
                    $folder = "w";
                    break;

                case "Catering";
                    $dbTable = "tbl_catering";
                    $dbIdColumn = "cId";
                    $folder = "c";
                    break;

                case "Functional Needs";
                    $dbTable = "tbl_fn";
                    $dbIdColumn = "fnId";
                    $folder = "f";
                    break;

                case "Lights/Stage Equipments";
                    $dbTable = "tbl_lse";
                    $dbIdColumn = "lseId";
                    $folder = "l";
                    break;

                case "Stages/Huts/Tents";
                    $dbTable = "tbl_sht";
                    $dbIdColumn = "shtId";
                    $folder = "s";
                    break;

                case "Music Instruments/Bands";
                    $dbTable = "tbl_mi";
                    $dbIdColumn = "miId";
                    $folder = "m";
                    break;

                default;
                    header("location:servWeddings.php");
            }


            $sql1 = "SELECT image FROM " . $dbTable . " WHERE catName = '$catName' AND sName = '$sName'";
            if ($output1 = mysqli_query($conn1, $sql1)) {
                if ($output->num_rows > 0) {
                    $row1 = $output1->fetch_assoc();
                }
            } else {
                echo("Error getting image");
            }

            $dateDiff = date_diff(date_create(date("Y-m-d")), date_create($row["orderDate"]));
            $fDateDiff = $dateDiff->format("%R%a");

            if ($fDateDiff > 0) {
                $status = "Processing";
            } else {
                $status = "Delivered";
            }


            echo('
								
									<table border="0" align="center" class="tblPHistory ' . $status . '">
										<tr>
											<td rowspan="6" width="350">
												<img src="images/service_cards/' . $folder . '/' . $row1["image"] . '" class="imgPHistory" alt="Item Image" />
											</td>
											<td>
												<p class="pHisLabel">Order Status</p>
											</td>
											<td>
												<p class="pHisDetails">: ' . $status . '</p>
											</td>
											<td>
											</td>										
										</tr>
										<tr>
											<td>
												<p class="pHisLabel">Service name</p>
											</td>
											<td>
												<input type="text" class="inputs" id="txtpHisItName" name="txtpHisItName" value=": ' . $row["sName"] . '" disabled="disabled" />
											</td>
											<td>
											</td>										
										</tr>
										<tr>
											<td>
												<p class="pHisLabel">Purchase Date</p>
											</td>
											<td>
												<input type="text" class="inputs" id="txtpHisPurDate" name="txtpHisPurDate" value=": ' . $row["transactionDate"] . '" disabled="disabled" />
											</td>
											<td>
											</td>
										</tr>
										<tr>
											<td>
												<p class="pHisLabel">Deliver Date</p>
											</td>
											<td>
												<p class="pHisDetails">: ' . $row["orderDate"] . '</p>
											</td>
											<td>
											</td>
										</tr>
										<tr>
											<td>
												<p class="pHisLabel">Payment</p>
											</td>
											<td>
												<p class="pHisDetails pHPrice">' . $row["price"] . '</p>
											</td>
											<td>
												<input type="submit" style="float:right" id="btnDeletePHis" name="btnDeletePHis" value="Delete" />
											</td>
										</tr>
									</table>

								');
        }
    }
} else {
    $done = "Error...!";
    echo($done);
}
?>				
                </form>
            </div>
        </div>


<?php
include_once("includes/footer.php");
?>

    </body>
</html>