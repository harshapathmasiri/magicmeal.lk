<?php session_start() ?>

<?php
$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientRow"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}
?>


<?php
include("includes/db.php");
$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);


$fName = "";
$lName = "";
$username = "";
$email = "";
$address = "";
$password = "";
$output = "";
$agreeError = "";


if (isset($_POST["btnRegister"])) {
    $fName = $_POST["txtFName"];
    $lName = $_POST["txtLName"];
    $username = $_POST["txtUsername"];
    $email = $_POST["txtEmail"];
    $address = $_POST["txtAddress"];

    if (isset($_POST["chkAgreement"]) == "agree") {
        $sql = "INSERT INTO tbl_client(fName,lName,username,email,address,password) VALUES('$fName','$lName','$username','$email','$address','" . md5("websters" . md5($_POST["txtPassword"])) . "')";
        $output = mysqli_query($conn, $sql);
    } else {
        $agreeError = "Please read and agree the agreement!";
        echo($agreeError);
    }

    if ($output) {
        header("location:login.php");
    }
}
?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/style_register.css" />

        <script src="js/script.js" type="text/javascript"></script>

        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Register | Magic Meal </title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body>

<?php
include_once("includes/navbar.php");
?>

        <div class="container">
            <form action="register.php" method="post" class="formRegister">
                <h1 class="registerTitle">Register</h1>
                <table border="0" align="center" class="tblRegisterForm">
                    <tr>
                        <td><label for="txtFName">First Name: </label></td>
                        <td><input type="text" id="txtFName" name="txtFName" class="inputs" placeholder="Type here..." /></td>
                    </tr>

                    <tr>
                        <td><label for="txtLName">Last Name: </label></td>
                        <td><input type="text" id="txtLName" name="txtLName" class="inputs" placeholder="Type here..." /></td>
                    </tr>

                    <tr>
                        <td><label for="txtUsername">Username: </label></td>
                        <td><input type="text" id="txtUsername" name="txtUsername" class="inputs" placeholder="Type here..." /></td>
                    </tr>

                    <tr>
                        <td><label for="txtEmail">Email: </label></td>
                        <td><input type="text" id="txtEmail" name="txtEmail" class="inputs" placeholder="example@ex.com" /></td>
                    </tr>

                    <tr>
                        <td><label for="txtAddress">Address: </label></td>
                        <td><textarea style="resize: none" id="txtAddress" name="txtAddress" class="inputs" placeholder="Type here..."></textarea></td>
                    </tr>

                    <tr>
                        <td><label for="txtRegPassword">Password: </label></td>
                        <td><input type="password" id="txtRegPassword" name="txtPassword" class="inputs" placeholder="Must be longer than 6 characters" /></td>
                    </tr>

                    <tr>
                        <td><label for="txtRegConfPassword">Confirm Password: </label></td>
                        <td><input type="password" id="txtRegConfPassword" name="txtConfPassword" class="inputs" /></td>
                    </tr>

                    <tr>
                        <td colspan="2" style="padding-top: 30px"><input type="checkbox" id="chkAgreement" name="chkAgreement" value="agree" /> <label for="chkAgreement"><small>I have read the user-agreement and I agree to it</small></label></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><input style="float: right" type="submit" name="btnRegister" id="btnRegister" value="Register" onclick="valRegister()"/></td>
                    </tr>
                    <tr>
                        <td colspan="2" <?php if ($loggedStatus) {
    echo("style='display: none;'");
} ?> style="padding-bottom: 20px"><a href="login.php" style="color: #222"><small>Have an account? Login</small></a></td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <small style="color: #777">*By registering in to Magic Meal, you are agreeing to our site's <a href="#" style="color: #999"> Terms and conditions</a> and our <a href="#" style="color: #999"> Privacy policy. </a></small>
                        </td>
                    </tr>
                </table>
            </form>
        </div>


<?php
include_once("includes/footer.php");
?>

    </body>
</html>