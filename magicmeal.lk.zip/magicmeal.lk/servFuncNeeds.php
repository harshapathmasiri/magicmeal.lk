<?php session_start() ?>

<?php
$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}
?>

<?php
include("includes/db.php");
$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);
$sql = "SELECT * FROM tbl_fn";
$output = mysqli_query($conn, $sql);
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/style_services.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/calendar.css" />


        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Buffet Catering | Service | Sandy's Catering Service</title>

        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/PINK-S.png"/>

        <script src="js/script.js" type="text/javascript"></script>

        <style>
            .SFN{
                background-color: #FFF;
                color: #38516A !important;
            }	

        </style>	

    </head>

    <body>
        <?php
        include_once("includes/navbar.php");
        include_once("includes/slider.php");
        ?>

        <div class="servNav" id="idServNav"> 
            <ul>
                <table align="center" border="0" class="tblServNav">
                    <tr>
                        <td>
                            <li><a href="servWeddings.php" class="aServNav WH">Seat - Back</a></li>
                        </td>
                        <td>    
                            <li><a href="servCatering.php" class="aServNav C">Wedding Catering</a></li>
                        </td>
                        <td>
                            <li><a href="servFuncNeeds.php" class="aServNav SFN">Buffet</a></li>
                        </td>
                        <td>
                            <li><a href="servLightSE.php" class="aServNav LSE">Lights</a></li>
                        </td>
                        <td>
                            <li><a href="servStageHT.php" class="aServNav SHT">Huts & Tents</a></li>
                        </td>
                        <td>
                            <li><a href="servMusicIB.php" class="aServNav MIB">Chairs</a></li>
                        </td>
                        <td>
                            <li><a href="serveShip.php" class="aServNav MIB">Shipboard Catering</a></li>
                        </td>
                        <td>
                            <li><a href="serveResturant.php" class="aServNav MIB">Restaurant Catering</a></li>
                        </td>
                    </tr>
                </table>        
            </ul>
        </div>

        <div class="container1">
            <h1 class="servTitle1">Buffet Catering</h1>

            <table align="center" border="0" class="tblServCards">
                <?php
                if ($output->num_rows > 0) {
                    while ($row = $output->fetch_assoc()) {
                        $A = explode(",", $row["Main Course"]);
                        $B = explode(",", $row["Dessert"]);
                        echo('
								<tr>

									<td class="coloredCol">
										<div class="sCard" id="sCardhall1">
											<div class="wedImg img">
												<img src="images/service_cards/c/' . $row["image"] . '" />
											</div>

											<div class="servCardDesc">
												<p>' . $row["cardDes"] . '</p>
											</div>
										</div>
									</td>
									<td>
										<div class="sBook">
											<h1 class="sOTitle">' . $row["sName"] . '</h1>
											<div class="servDetails">
												<table border="0" align="left" class="tblServDetails">
													<tr>
														<td>
															Welcome drink: 
														</td>
														<td>
															' . $row["Welcome Drink"] . ' </br><small style="font-size: 11px">(*conditions apply)</small>
														</td>
													</tr>

													<tr>
														<td>
															Starters:
														</td>
														<td>
															' . $row["Starters"] . '  <small style="font-size: 11px">(*conditions apply)</small>
														</td>
													</tr>

													<tr>
														<td>
															Main course:
														</td>
														<td>');
                        for ($i = 0; $i < sizeof($A); $i++) {
                            echo($A[$i] . "<br />");
                        }
                        echo('</td>
													</tr>

													<tr>
														<td>
															Dessert:
														</td>
														<td>');
                        for ($i = 0; $i < sizeof($B); $i++) {
                            echo($B[$i] . "<br />");
                        }
                        echo('</td>
													</tr>

												</table>
												<a href="book.php?sId=' . $row["fnId"] . '&sName=' . $row["sName"] . '&catName=' . $row["catName"] . '" class="aSerOrdBook">Book now</a>
												<p class="pricePerItem">LKR ' . number_format($row["price"]) . '/= <small>(per plate)</small></p>
											</div>
										</div>
									</td>
								</tr>

								<tr><td colspan="2"></td></tr>
						
							');
                    }
                }
                ?>

            </table>
        </div>  

        <?php
        include_once("includes/footer.php");
        ?>

        <script type="text/javascript">
            showSlides();
        </script>

    </body>

</html>