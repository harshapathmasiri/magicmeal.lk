<?php session_start() ?>

<?php
$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}
?>

<?php
include("includes/db.php");
$conn = mysqli_connect($dbHost, $dbUname, $dbPass, $dbName);
$sql = "SELECT * FROM tbl_lse";
$output = mysqli_query($conn, $sql);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/style_services.css" />
        <link rel="stylesheet" type="text/css" href="css/animations.css" />
        <link rel="stylesheet" type="text/css" href="css/calendar.css" />


        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Lights | Service | Sandy's Catering Service</title>


        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/PINK-S.png"/>
        
        <script src="js/script.js" type="text/javascript"></script>

    </head>

    <style>
        .LSE{
            background-color: #FFF;
            color: #38516A !important;
        }	

    </style>	


    <body>
        <?php
        include_once("includes/navbar.php");
        include_once("includes/slider.php");
        ?>

        <div class="servNav" id="idServNav"> 
            <ul>
                <table align="center" border="0" class="tblServNav">
                    <tr>
                        <td>
                            <li><a href="servWeddings.php" class="aServNav WH">Seat - Back</a></li>
                        </td>
                        <td>    
                            <li><a href="servCatering.php" class="aServNav C">Wedding Catering</a></li>
                        </td>
                        <td>
                            <li><a href="servFuncNeeds.php" class="aServNav FN">Buffet</a></li>
                        </td>
                        <td>
                            <li><a href="servLightSE.php" class="aServNav LSE">Lights</a></li>
                        </td>
                        <td>
                            <li><a href="servStageHT.php" class="aServNav SHT">Huts & Tents</a></li>
                        </td>
                        <td>
                            <li><a href="servMusicIB.php" class="aServNav MIB">Chairs</a></li>
                        </td>
                        <td>
                            <li><a href="serveShip.php" class="aServNav MIB">Shipboard Catering</a></li>
                        </td>
                        <td>
                            <li><a href="serveResturant.php" class="aServNav MIB">Restaurant Catering</a></li>
                        </td>
                    </tr>
                </table>        
            </ul>
        </div>

        <div class="container1">
            <h1 class="servTitle1">Lights</h1>

            <table align="center" border="0" class="tblServCards">
                <?php
                if ($output->num_rows > 0) {
                    while ($row = $output->fetch_assoc()) {
                        echo('
							<tr>
								<td class="coloredCol" width="350">
									<div class="sCard" id="sCardhall1">
										<div class="wedImg img">
											<img src="images/service_cards/l/' . $row["image"] . '" />
										</div>

										<div class="servCardDesc">
											<p>' . $row["cardDes"] . '</p>
										</div>
									</div>
								</td>
								<td>
									<div class="sBook">
										<h1 class="sOTitle">' . $row["sName"] . '</h1>
										<div class="servDetails">
											<table border="0" align="left" class="tblServDetails">
												<tr>
													<td width="100">
														Dimensions: 
													</td>
													<td>
														' . $row["dimension"] . ' <small style="font-size: 11px">(inches)</small>
													</td>
												</tr>

												<tr>
													<td>
														Watt:
													</td>
													<td>
														' . $row["watt"] . '
													</td>
												</tr>
												<tr>
													<td>
														Color:
													</td>
													<td>
														' . $row["color"] . '
													</td>
												</tr>
											</table>
											<a href="book.php?sId=' . $row["lseId"] . '&sName=' . $row["sName"] . '&catName=' . $row["catName"] . '" class="aSerOrdBook">Book now</a>
											<p class="pricePerItem">LKR ' . number_format($row["price"]) . '/= <small>(per function)</small></p>
									</div>
								</td>
							</tr>

							<tr><td colspan="2"></td></tr>
						');
                    }
                }
                ?>
            </table>
        </div>    

        <?php
        include_once("includes/footer.php");
        ?>

        <script type="text/javascript">
            showSlides();
        </script>

    </body>

</html>