<?php session_start() ?>

<?php
$loggedStatus = 0;

if (isset($_SESSION["clientLogin"])) {
    if ($_SESSION["clientLogin"]) {
        $loggedStatus = 1;
    }
} else {
    $loggedStatus = 0;
}

if(isset($_GET['addItem'])){
    $item = $_GET['item'];
    $price = $_GET['price'];
    $_SESSION['items'] .= $item.',';
    $_SESSION['prices'] .= $price.',';
    ?>
    <script type="text/javascript">
        alert('Added to cart!');
    </script>
    <?php

}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" type="text/css" href="css/style_nav_footer.css" />
        <link rel="stylesheet" type="text/css" href="css/style_index.css" />
        <link rel="stylesheet" type="text/css" href="css/" />

        <script src="js/script.js"></script>

        

        <title>Our Menu | Magic Meal</title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
    </head>

    <body>
        <?php
        include_once("includes/navbar.php");
        ?>

        <div class="content1">
            <table align="center" border="0" class="tblServCards">
                <tr>

                     <div class="content1">
            <h1 class="servTitle">Our Menu | 
            Place Your Oder Here</h1>
          
            <table align="center" border="0" class="tblServCards">
                <tr>

                    <td>
                        <div class="weddings sCard">
                            <div class="servCardOverlay">
                                <a href="?addItem=true&item=Shrimp and Bacon Stir Fry Rice&price=Rs.3690/-" class="servCardOverlayBtnView">Rs.3,690.00 Add</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/service_cards/rice1.PNG" />
                                <p class="servCardTitle">Shrimp and Bacon Stir Fry Rice - One Plate</p>
                            </div>

                    <td>
                        <div class="weddings sCard">
                            <div class="servCardOverlay">
                                <a href="?addItem=true&item=Test Food&price=Rs.6000" class="servCardOverlayBtnView">Rs.6000.00 Add</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/service_cards/rice1 - Copy.png" />
                                <p class="servCardTitle">Test Food - One Plate</p>
                            </div>


                            <div class="servCardDesc">
                                <p>New Food Dish.</p>
                            </div>
                        </div>
                    </td>           

                    <td>
                        <div class="catering sCard">
                            <div class="servCardOverlay">
                                <a href="?addItem=true&item=Easy Pineapple Fried Rice&price=Rs.1790/-" class="servCardOverlayBtnView">Rs.3,790.00 Add</a>
                            </div>
                            <div class="caterImg img">
                                <img src="images/service_cards/rice2.PNG" />
                                <p class="servCardTitle">Easy Pineapple Fried Rice</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Pineapple added to anything automatically makes it good. Fried rice is no exception; plus, you have the added bonus of this recipe being super easy - One Plate</p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="Functions sCard">
                            <div class="servCardOverlay">
                                <a href="servFuncNeeds.php" class="servCardOverlayBtnView">Rs.3,990.00 Add</a>
                            </div>
                            <div class="functionsImg img">
                                <img src="images/service_cards/image3.PNG" />
                                <p class="servCardTitle">Cauliflower Fried Rice</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Eating your cauliflower never tasted so good. Mom would be proud - One Plate.</p>
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td>
                        <div class="lights sCard">
                            <div class="servCardOverlay">
                                <a href="servLightSE.php" class="servCardOverlayBtnView">Rs.4,190.00 Add</a>
                            </div>
                            <div class="lightsImg img">
                                <img src="images/service_cards/rice4.PNG" />
                                <p class="servCardTitle">Ham Fried Rice</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Want ham for dinner but think it seems a little, well, boring? Spruce it up with a nice dose of rice - One Plate!0</p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="stages sCard">
                            <div class="servCardOverlay">
                                <a href="servStageHT.php" class="servCardOverlayBtnView">Rs.4,050.00 Add</a>
                            </div>
                            <div class="stagesImg img">
                                <img src="images/service_cards/rice5.PNG" />
                                <p class="servCardTitle">Vegetable Fried Rice</p>
                            </div>

                            <div class="servCardDesc">
                                <p>This vegetarian fried rice is great for so many reasons: tons of veggies, tons of flavor, tons of fill-you-up deliciousness - One Plate.</p>
                            </div>
                        </div>
                    </td>

                    <td>
                        <div class="music sCard">
                            <div class="servCardOverlay">
                                <a href="servMusicIB.php" class="servCardOverlayBtnView">Rs.4,390.00 Add</a>
                            </div>
                            <div class="musicImg img">
                                <img src="images/service_cards/image6.PNG" />
                                <p class="servCardTitle">Baked Fried Brown Rice</p>
                            </div>

                            <div class="servCardDesc">
                                <p>Guess what? You don't even have to fry your fried rice — you can bake it! Yeah, crazytown, but it's true. You will love, love, love this rice - One Plate.</p>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <?php
        include_once("includes/footer.php");
        ?>
        <script type="text/javascript">

        </script>

        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDz_qDNvKnEONeyMDwl0jRB8R39YkYDyiQ &callback=initMap" type="text/javascript"></script>


    </body>

</html>


                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/1.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/1.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/2.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/2.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/3.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/3.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/4.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/4.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/5.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/5.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/6.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/6.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/7.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/7.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/8.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/8.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/9.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/9.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/10.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/10.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/11.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/11.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/12.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/12.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/13.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/13.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/14.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/14.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/15.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/15.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/16.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/16.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/17.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/17.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/18.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/18.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>

                <tr>

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/19.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/19.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/20.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/20.jpg" />
                            </div>
                        </div>
                    </td>			

                    <td style="padding-top: 100px;">
                        <div class="weddings gCard">
                            <div class="servCardOverlay">
                                <a href="images/gallery/21.jpg" class="servCardOverlayBtnView">View</a>
                            </div>
                            <div class="wedImg img">
                                <img src="images/gallery/21.jpg" />
                            </div>
                        </div>
                    </td>

                </tr>
            </table>
        </div>

        <?php
        include_once("includes/footer.php");
        ?>
        <script type="text/javascript">

        </script>

        <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDz_qDNvKnEONeyMDwl0jRB8R39YkYDyiQ &callback=initMap" type="text/javascript"></script>


    </body>

</html>
