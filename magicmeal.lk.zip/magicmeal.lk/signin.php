
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <title>Login Form | Magic Meal/title>
        
        <!-- Favicon  -->
        <link rel="shortcut icon" href="images/Magic-Meal-Logo.png"/>
        
        <style>


            .top{
                margin-top: 300px;
            }
            .navbar{
                border-radius: 0 !important; 
            }

            body {
                font-family: 'Roboto', sans-serif;
                line-height: 30px;
            }
            a{
                text-decoration: none;
            }
            a:hover{
                text-decoration: none;
            }
            .set-radius-zero {
                border-radius: 0px;
                -moz-border-radius: 0px;
                -webkit-border-radius: 0px;
            }

            .content-wrapper { 
                height: auto;
                padding-bottom: 60px;
            }

            .page-head-line {
                font-weight: 500;
                padding-bottom: 20px;
                border-bottom: 2px solid #F0677C;
                text-transform: uppercase;
                color: #F0677C;
                font-size: 20px;
                margin-bottom: 40px;
            }

            .btn {
                border-radius: 0px;
                -webkit-border-radius: 0px;
                -moz-border-radius: 0px;
            }

            .progress2 {
                height: 8px;
                border-radius: 0px;
                -webkit-border-radius: 0px;
                -moz-border-radius: 0px;
            }
            .login-icon {
                height: 60px;
                width: 60px;
                padding: 13px;
                border-radius: 50%;
                font-size: 30px;
                margin-bottom: 20px;
                color: #fff;
                text-align: center;
                cursor:pointer;
                background-color:#F0677C;
                -webkit-border-radius:50%;
                -moz-border-radius:50%;
            }

            .left-div {
                padding-left: 30px;
                margin-top: 40px;
                margin-bottom: 30px;
            }



            /* USER SETTINGS DIV */
            .user-settings-wrapper .nav > li > a {
                position: relative;
                display: block;
                padding: 15px 18px;
                border-radius: 50%;
                -webkit-border-radius: 50%;
                -moz-border-radius: 50%;
                height: 60px;
                width: 60px;
                background-color: #F0677C;
                color: #fff;
            }

            .user-settings-wrapper {
                margin-top: 10px;
            }

            .user-settings-wrapper li {
                display: inline-block;
            }

            .user-settings-wrapper .dropdown-settings {
                width: 200px;
                padding: 10px;
            }

            .user-settings-wrapper .nav > li > a:hover,.user-settings-wrapper .nav > li > a:focus {
                text-decoration: none;
                background-color: #C36464!important;
            }

            .user-settings-wrapper img {
                height: 64px;
                width: 64px;
                border: 1px solid #000000;
            }

            .user-settings-wrapper .dropdown-menu {
                margin: 0px;
                border-radius: 0px!important;
                -moz-border-radius: 0px!important;
                -webkit-border-radius: 0px!important;
            }

            .user-settings-wrapper .btn {
                border-radius: 0px!important;
                -moz-border-radius: 0px!important;
                -webkit-border-radius: 0px!important;
            }

            .user-settings-wrapper .media-heading {
                padding-top: 10px;
            }

            /* MENU LINKS SECTION*/

            .menu-section {
                background-color: #3D3D3D;
            }

            #menu-top a {
                color: #FFF;
                text-decoration: none;
                font-weight: 500;
                padding: 10px 10px 10px 10px;
                text-transform: uppercase;
            }

            .menu-top-active {
                background-color: #C36464;
            }

            .menu-section .nav > li > a:hover,.menu-section .nav > li > a:focus {
                background-color: #F0677C!important;
            }

            .menu-section .dropdown-menu > li > a:hover,.menu-section .dropdown-menu > li > a:focus {
                background-color: #F0677C!important;
            }


            footer {
                padding: 2px;
                color: #fff;
                font-size: 12px;
                background-color: #C36464;
            }

            footer a, footer a:hover {
                color: #fff;
                text-decoration: none;
            }



            .bk-clr-one {
                background-color: #B9B739;
            }

            .bk-clr-two {
                background-color: #F94C4C;
            }

            .bk-clr-three {
                background-color: #119c7e;
            }

            .bk-clr-four {
                background-color: #b739b9;
            }

            .dashboard-div-icon {
                height: 75px;
                width: 75px;
                border: 2px solid #fff;
                padding: 20px;
                border-radius: 50%;
                -webkit-border-radius:50%;
                -moz-border-radius:50%;
                font-size: 30px;
                margin-bottom: 20px;
                color: #fff;
            }

            .dashboard-div-wrapper {
                border-radius: 5px;
                text-align: center;
                padding: 15px;
                color: #fff;
                margin-bottom: 50px;
            }

            .dashboard-div-wrapper .progress {
                height: 2px;
            }

            /* NOTICE BOARD */


            .notice-board .panel {
                border-radius: 0px;
                -webkit-border-radius: 0px;
                -moz-border-radius: 0px;
            }

            .notice-board ul {
                padding-left: 0px;
                list-style: none;
            }

            .notice-board li {
                padding: 10px;
                border-bottom: 1px solid #E5E5E5;
            }

            .notice-board li span {
                margin-right: 10px;
                border: 1px solid #DBDBDB;
                padding: 5px;
            }

            .notice-board li a, li a:hover {
                text-decoration: none;
                color: #000;
            }

            /* SOCIAL BUTTONS */
            .btn-social {
                color: white;
                opacity: 0.8;
            }

            .btn-social:hover {
                color: white;
                opacity: 1;
                text-decoration: none;
            }

            .btn-facebook {
                background-color: #3b5998;
            }

            .btn-twitter {
                background-color: #00aced;
            }

            .btn-linkedin {
                background-color: #0e76a8;
            }

            .btn-google {
                background-color: #c32f10;
            }


            #footer {
                position:fixed;
                left:0px;
                bottom:0px;
                height:auto;
                width:100%;
                background:#222222;
                border-bottom: 1px solid #000;
            }

            /* IE 6 */
            * html #footer {
                position:absolute;

            }

            .footer p{
                text-align: center;
                padding: 0;
                margin: 0;
                color: #ccc;
            }



            .delete{
                padding: 5px 8px; 
                color: #fff;
                background-color: #E13300;
                border-radius: 3px;
                border: 0;
            }
            .addartist{
                padding: 5px 8px; 
                color: #fff;
                background-color: #449d44;
                border-radius: 3px;
                border: 0;
            }
            .addsongsnew{
                padding: 5px 8px; 
                color: #fff;
                background-color: #b739b9;
                border-radius: 3px;
                border: 0;
            }
            .edit{
                padding: 5px 8px; 
                color: #fff;
                background-color: #1087dd;
                border-radius: 3px;
                border: 0;
            }

            .pictuers{
                padding: 5px 8px; 
                color: #fff;
                background-color: #449d44;
                border-radius: 3px;
                border: 0;
            }

            .slider-image{
                width: auto;
                height: auto;
                padding: 10px 0 5px 0;    
            }

            .image-option{
                width: auto;
                height: auto; 
                padding-bottom: 5px;
            }


            .maxlinetitle{
                width: 100%;
                height: auto;
                color: #333;
                font-size: 16px;
                text-align: left;
                display: inline-block; 
                padding: 0;
                margin: 0;
                overflow: hidden !important;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
            .number-class{
                position: absolute; 
                background-color: white;
                padding: 0px 2px 0px 1px;
                border: solid 1px #8E8E8E;
                border-radius: 3px;
                margin: 1px;
                font-size: 12px;
            }

            #sortable {  
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
            }

            #sortable li {
                float: left;
                padding: 2px;
                margin: 3px;
                cursor: move;
            } 
        </style>

    </head>
    <body>


        <!-- MENU SECTION END-->
        <div class="content-wrapper">
            <div class="container top">

                <div class="row">
                    <div class="col-md-3 col-sm-3 col-xs-6">

                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-6">
                        <a href="admin/login.php">
                            <div class="dashboard-div-wrapper bk-clr-two">
                                <i  class="fa fa-eye fa-2x dashboard-div-icon" ></i>
                                <div class="progress progress-striped active">
                                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
                                    </div>

                                </div>
                                <h5>Admin</h5>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-6">
                        <a href="login.php">
                            <div class="dashboard-div-wrapper bk-clr-three">
                                <i  class="fa fa-cogs fa-2x dashboard-div-icon" ></i>
                                <div class="progress progress-striped active">
                                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                                    </div>

                                </div>
                                <h5>User</h5>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-3 col-sm-3 col-xs-6">

                    </div>

                </div>

                <div class="row" style="height: 130px;">

                </div>

            </div>
        </div>
        <!-- CONTENT-WRAPPER SECTION END-->

    </body>
</html>
